# Plan 05-12 preparation

Preparation only. The nine source/test files and amended plan are in this temporary tree. No checkout source, planning, configuration, analyzer census, index, or commit writes were made. Parent integration and explicit GO remain required. Actual model token telemetry is unavailable; the plan estimate is not an actual token count.

## Ownership and application

`owned-paths.json` is the exact nine-file owner set. Task 1 owns config-io and completion-cache with their two paired tests (four files). Task 2 owns state-io, its paired test, both declared architecture files, and install-flow.test.ts (five files). `05-12-PLAN.md` amends only these tasks to record the approved validation-flow retirement and public proofs. There is no scope extension.

The hooks foundation baseline is Plan 05-11's final prepared file, supplied by execute_agent_names and subsequently applied by that owner. Its public hook parsing, lenience, strict resolution, and negative type proofs remain unchanged by this plan. All nine baseline files matched the live checkout on the preparation hash audit. `file-manifest.json` records exact baseline/prepared SHA-256 hashes; apply only after rechecking these hashes. `prepared.patch` contains only the nine files. The amended plan is separate.

## Finding dispositions

The real isolated production Fallow comparison used two copies differing only by the nine owner files. Its report reader retained normal exit-status validation, all report categories, includeEntryExports=true, and private-type-leaks=error. Production mode was enabled only in the two isolated analyzer copies. Both reports found ten entry points and returned normal issue exit status 1. The exact comparison is **41 → 34**, these seven removals and **zero additions**:

| Finding identity | Disposition and production caller evidence |
| --- | --- |
| `unused_exports\|extensions/pi-claude-marketplace/persistence/config-io.ts\|CONFIG_VALIDATOR` | Private. Public loadConfig/saveConfig still validate through the same compiled schema. |
| `unused_exports\|extensions/pi-claude-marketplace/persistence/state-io.ts\|PLUGIN_INSTALL_RECORD_SCHEMA` | Private. STATE_SCHEMA embeds it and the real public PluginInstallRecord type remains derived from it. |
| `unused_exports\|extensions/pi-claude-marketplace/persistence/state-io.ts\|STATE_SCHEMA` | Private. STATE_VALIDATOR compiles it; the real public ExtensionState type remains derived from it. |
| `unused_exports\|extensions/pi-claude-marketplace/persistence/state-io.ts\|STATE_VALIDATOR` | Private. Public loadState/saveState validate through it. The two install-flow tests now obtain typed snapshots through public loadState. |
| `unused_exports\|extensions/pi-claude-marketplace/shared/completion-cache.ts\|MARKETPLACE_NAMES_CACHE_SCHEMA` | Retired with its exclusive schema-representation test. The marketplace-name reader was already removed. No runtime production caller remains; invalidation still deletes the names cache and preserves its errors. |
| `unused_exports\|extensions/pi-claude-marketplace/shared/completion-cache.ts\|PLUGIN_INDEX_CACHE_SCHEMA` | Private. PLUGIN_INDEX_VALIDATOR still validates disk caches for the real CompletionCache public operations. |
| `unused_types\|extensions/pi-claude-marketplace/persistence/state-io.ts\|EnabledPluginRecord` | Retired unused alias. It was PluginInstallRecord intersected with enabled:true, consumed only by two test type expressions. No live public signature used the narrower alias. |

No new private type leaks or unused types were reported. The schemas are still used by the real public record types; no additional type export or fake reader was introduced. `fallow-comparison.json` contains both complete normalized reports and identities. `compare-fallow.mjs` reproduces the identity comparison using the canonical report reader against `/tmp/05-12-fallow-before` and `/tmp/05-12-fallow-after`; their absolute issue totals belong to that snapshot, not a mutable checkout census.

## Validation design and exact historical retirement

Installed TypeBox **1.3.28**, `node_modules/typebox/build/compile/validator.mjs`, implements accelerated `Errors(value)` by invoking the same validator Check and returning `[]` if it succeeds. Otherwise it produces the actual schema issues. Its TypeScript Errors signature returns an error array and does not narrow the input. The schemas here use ordinary object/primitive/array/union validation without side-effecting custom validators.

The old code ran Check and then Errors. Two tests patched Errors to return `[]` after Check rejected the input. These contradictions were the only reason for `(no detail available)`. The approved replacement uses the first actual error to decide validity and passes that issue to the formatter. With no issues, loadConfig has one documented assertion to ScopeConfig and loadState has one to ExtensionState. No corrective Parse, public context parameter, custom getter, Proxy validator, loader, cast around validation, or exception suppression was added.

`typebox-contract-probe.mjs` and `typebox-contract.json` document the installed behavior on a generated JSON-compatible corpus: config 126 cases (19 accepted, 107 rejected), state 518 (112 accepted, 406 rejected), **644 total**. Every case agrees between Check and absence of Errors; validation does not mutate the inputs, and every rejected case has a real first issue with string path/message. The probe now imports the original exported validators from the isolated before tree, so it remains runnable after privatization. The same first Errors issue supplies the new diagnostic, preserving its order and formatter.

The measured valid-input loop used 100,000 iterations for each API: config Check 58.000ms, Errors 50.106ms; state Check 141.650ms, Errors 130.838ms. These are noisy local measurements, not a speedup claim. The installed fast path and this sample show no material valid-input regression; invalid inputs no longer repeat the initial Check before asking Errors for their existing diagnostic list.

The following historical statements are explicitly retired:

1. Config load could report exactly `schema validation failed: (no detail available)` after a test replaced Errors with an empty result. No real JSON value causes that split-pass state. All actual root/nested invalid results remain exact.
2. State save could throw Error with message `saveState refused: in-memory state failed schema validation: (no detail available)` and undefined cause after the same forced contradiction. Its no-write promise is retained on real invalid save cases and strengthened for the three malformed plugins.
3. State load of `{}` could throw a root-object schema error after a test replaced Check and supplied errors for a different value, null. Real normalization produces an object before validation; real legacy null already loads as empty without rewriting its bytes. The actual root diagnostic is exercised with saveState(null), asserting Error class/name, exact save prefix and `<root>: must be object`, undefined cause, and unchanged existing bytes.
4. EnabledPluginRecord's unused enabled:true-only alias disappears. Its complete positive record remains a genuine PluginInstallRecord proof. The old negative `{enabled:false}` failed for missing required installation fields as well as the alias discriminant; it now explicitly proves incomplete-record rejection. The alias-only true-discriminant claim is retired, not mislabeled as a retained public output contract. Live DisabledPluginRecord and toDisabledRecord discrimination, field preservation, and reference/clone proofs remain unchanged.

## Assertion ledger

`assertion-inventory.json` inventories every original and prepared test call, assertion expression, satisfies expression, and @ts-expect-error line in all six owned test files. `assertion-ledger.json` assigns a disposition to **each of the 864 original assert call nodes**: **831 retain identical text in the same case**, **33 are explicitly migrated or retired**. Nested assertions inside rejection predicates are counted as their own nodes as well as inside the containing rejection expression. These are AST counts, not discovered runtime test counts.

| Original proof | Replacement or explicit retirement |
| --- | --- |
| Config complete version-1 Check=true | Same complete document loads through loadConfig; full independent status/filePath/config equality replaces the boolean. All malformed JSON, read failures, null root, nested required/type errors, invalid saves, path containment, exact bytes, and no-write assertions remain. |
| Config forced no-detail result | Retired impossible contradiction as detailed above; exact real invalid config results remain. |
| Marketplace names schema JSON representation | Retired with the unread declaration. Existing absent reader export, invalidation success/idempotency, and non-ENOENT unlink error assertions remain. |
| Plugin index schema full JSON representation | Runtime version-6 cache hydrates all nine status literals with complete name/status/version rows and unchanged exact file bytes. Eleven malformed-field rows prove required schemaVersion/timestamp/plugins and required name/status, plus timestamp/manifestRef/loadError/plugins/name/version types, through real rebuilds and exact complete serialized bytes. Existing version 5/7, unknown status, malformed JSON, empty/single cache cardinality, TTL before/at/after, milliseconds, memory isolation, manifest reference, poison, errors, and invalidation assertions remain. Exact public status equality preserves the closed vocabulary even against widening to string. JSON Schema metadata representation and union ordering themselves are private and retired. |
| Four state version Check booleans | Three accepted cases now assert complete public load outputs (v1 normalizes to v2, v2 remains v2, optional stamp remains). The v3 rejection maps to the existing exact unsupported-version error with future bytes retained. Existing v1 save exact bytes also remain. |
| Complete hook/SHA plugin Check=true | Real loadState compares the complete result to the independent literal input record; the existing exact-byte hookEntries/resolvedSha save/load round trip remains. |
| Forced state loader root diagnostic | Actual saveState(null) Error class/name/exact root diagnostic/cause and unchanged bytes; the manufactured loader prefix is explicitly retired. |
| Forced state no-detail error and retained bytes | Impossible error text retired; actual invalid save and root/plugin cases retain the no-write guarantee. |
| Three malformed plugin Check=false results | Each now rejects saveState with Error class/name/exact path+first message/undefined cause and unchanged complete existing bytes. No double type assertion: the intentional unchecked input is marked with a negative compiler directive. |
| COMPAT persisted key set | Exact public keyof PluginInstallRecord equals the independent inherited nine keys; full saved-record bytes remain in the paired owner. Added optional persisted field is a demonstrated compiler failure. |
| COMPAT seven forbidden manifest/orphan spellings absent | Exact public-key extraction equals never, preserving the same seven spellings; nine-key equality independently rejects any new key. |
| COMPAT exact version union | Exact public ExtensionState.schemaVersion equals 1|2, plus existing DEFAULT_STATE=2 and real load/save version cases. Added version3 is a demonstrated compiler failure. |
| Foundation four TypeBox version-union introspection assertions | Exact public version equality plus public load/save/rejection cases. Private anyOf representation/count plumbing retires. |
| Foundation thirteen schema traversal/resource assertions | Schema-navigation existence assertions retire as private representation plumbing. Exact public resources type preserves all five required string arrays, including hooks; actual missing/non-array hooks reject save, and full resource records round-trip. Optional hooks is a demonstrated compiler failure. |
| Two install-flow validator-based JSON.parse narrowing sites | Typed before-snapshots come from actual loadState, selected by the exact preexisting state bytes. Existing race simulation remains; **all outcome, error, notification, rollback, retry, byte, and interaction assertions remain identical**. No new production seam or validator mutation. |

The new malformed cache byte checks fix Date per case because the existing cache writer serializes with internal `new Date()`. The public `options.now` controls TTL only and cannot determine those bytes. Each case uses its own node:test timer context and temporary directory; no production clock policy changes. Expected records and complete byte strings are independently written. No metadata-only boolean test was substituted for a runtime contract.

## Verification and controls

Genuine Node **v26.8.2**, unsandboxed test process with authorized escalation:

`node --test tests/persistence/config-io.test.ts tests/persistence/state-io.test.ts tests/shared/completion-cache.test.ts tests/architecture/compat-01-no-expansion.test.ts tests/architecture/hooks-foundation.test.ts tests/orchestrators/plugin/install-flow.test.ts`

Final discovery: **243 tests, 243 passed, 6 suites, 0 failed/cancelled/skipped/todo**. `owner-tests.log` is complete. A prior preparation run lacked docs/output-catalog.md in the temporary tree; copying the unchanged documentation fixture fixed that harness omission. No test failure in production behavior was hidden.

Direct owner commands use the installed `scripts/test-coverage-direct.mjs` with each exact source path, not aggregate coverage:

| Source | Branches | Functions | Lines |
| --- | --- | --- | --- |
| persistence/config-io.ts | 17/17 | 4/4 | 195/195 |
| persistence/state-io.ts | 54/54 | 9/9 | 494/494 |
| shared/completion-cache.ts | 48/48 | 15/15 | 389/389 |

Owner TypeScript uses `node node_modules/typescript/bin/tsc --project tsconfig.owner.json --pretty false`; that temporary config includes the six owner tests and follows their actual source imports. ESLint is scoped to the exact nine owned files. Formatting uses installed Prettier's API and the repository's options, since its CLI ignores /tmp paths. No repository gate setting changed.

`drift-controls.mjs` and `drift-controls.json` record deliberate mutations in `/tmp/05-12-controls`, with source restoration in finally. Benign compilation and the unmodified real state owner tests pass. Added optional persisted field, added status literal, broad string status, added state version, and optional hooks each fail compilation at the named exact public proof. Removing hookEntries from save output fails the existing full saved-record assertion. The earlier control harness mistakenly expected 39 state tests while the observed owner discovers 38; its expected count was corrected and the controls rerun. This did not change or skip any production test.

Parent must still run stable-wave integration: complete census reconciliation, strict analyzer offender/benign gate, whole typecheck/lint/check, and exact aggregate production coverage. Those checks were intentionally not run against the concurrently changing checkout. Preparation does not claim integrated completion, does not write canonical SUMMARY.md, and does not commit.
