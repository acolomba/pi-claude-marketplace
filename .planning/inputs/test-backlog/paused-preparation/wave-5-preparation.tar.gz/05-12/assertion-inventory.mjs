import fs from "node:fs/promises";
import ts from "typescript";

const root = "/tmp/05-12-preparation/";
const paths = JSON.parse(await fs.readFile(root + "owned-paths.json", "utf8"));
const inventory = [];
for (const path of paths.filter((path) => path.startsWith("tests/"))) {
  const versions = {};
  for (const [version, prefix] of [["before", "baseline/"], ["prepared", ""]]) {
    const text = await fs.readFile(root + prefix + path, "utf8");
    const source = ts.createSourceFile(path, text, ts.ScriptTarget.Latest, true);
    const cases = [];
    const proofs = [];
    function visit(node) {
      if (ts.isCallExpression(node) && node.expression.getText(source) === "test") {
        const assertions = [];
        function collect(child) {
          if (ts.isCallExpression(child) && /^assert\./u.test(child.expression.getText(source))) {
            assertions.push({line: source.getLineAndCharacterOfPosition(child.getStart(source)).line + 1, text: child.getText(source)});
          }
          ts.forEachChild(child, collect);
        }
        collect(node);
        cases.push({name: node.arguments[0]?.getText(source), line: source.getLineAndCharacterOfPosition(node.getStart(source)).line + 1, assertions});
      }
      if (ts.isSatisfiesExpression(node)) {
        proofs.push({line: source.getLineAndCharacterOfPosition(node.getStart(source)).line + 1, text: node.getText(source)});
      }
      ts.forEachChild(node, visit);
    }
    visit(source);
    versions[version] = {cases, satisfies: proofs, negativeDirectives: text.split("\n").flatMap((line,index) => line.includes("@ts-expect-error") ? [{line:index+1,text:line.trim()}] : [])};
  }
  inventory.push({path,...versions});
}
await fs.writeFile(root + "assertion-inventory.json",JSON.stringify(inventory,null,2)+"\n");
