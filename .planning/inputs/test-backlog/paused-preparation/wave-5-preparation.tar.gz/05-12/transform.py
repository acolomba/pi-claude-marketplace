from pathlib import Path
import json,re,shutil
r=Path('/tmp/05-12-preparation')
def edit(rel,fn):
 p=r/rel;p.write_text(fn(p.read_text()))

for module,validator,detail,public_type,value in [
 ('config-io','CONFIG_VALIDATOR','firstConfigValidationErrorDetail','ScopeConfig','parsed'),
 ('state-io','STATE_VALIDATOR','firstValidationErrorDetail','ExtensionState','normalized')]:
 def source(s):
  s=s.replace('export const '+validator,'const '+validator)
  s=re.sub(r'function '+detail+r'\(value: unknown\): string \{.*?\n\}', 'function '+detail+'(first: { readonly instancePath: string; readonly message: string }): string {\n  return `${first.instancePath || "<root>"}: ${first.message}`;\n}',s,flags=re.S)
  for arg in [value,'config' if module=='config-io' else 'state']:
   s=s.replace('  if (!'+validator+'.Check('+arg+')) {','  const [validationError] = '+validator+'.Errors('+arg+');\n  if (validationError !== undefined) {')
   s=s.replace(detail+'('+arg+')',detail+'(validationError)')
  if module=='config-io':
   s=s.replace('  return { status: "valid", filePath, config: parsed };','  // Errors uses the same compiled schema; no issues proves this parsed JSON has the public shape.\n  return { status: "valid", filePath, config: parsed as ScopeConfig };')
  else:
   s=s.replace('export const PLUGIN_INSTALL_RECORD_SCHEMA','const PLUGIN_INSTALL_RECORD_SCHEMA').replace('export const STATE_SCHEMA','const STATE_SCHEMA')
   s=s.replace('export type EnabledPluginRecord = PluginInstallRecord & { enabled: true };\n','')
   s=s.replace('  return normalized;','  // No schema issues proves the normalized JSON has the public state shape.\n  return normalized as ExtensionState;')
   s=s.replace('void persistMigratedState(stateJsonPath, normalized);','void persistMigratedState(stateJsonPath, normalized as ExtensionState);')
   s=s.replace(' * COMPAT-01: exported so the no-expansion gate reads the record\'s key set off\n * this single source of truth rather than a hand-maintained field list that\n * would drift. No production consumer imports it; the schema stays the sole\n * validation boundary for the persisted record.', ' * COMPAT-01: the public PluginInstallRecord type and saved records expose the\n * compatibility contract; the schema remains this module\'s validation boundary.')
  return s
 edit('extensions/pi-claude-marketplace/persistence/'+module+'.ts',source)

def cache(s):
 s=re.sub(r'export const MARKETPLACE_NAMES_CACHE_SCHEMA = Type.Object\(\{.*?\n\}\);\n\n','',s,flags=re.S)
 return s.replace('export const PLUGIN_INDEX_CACHE_SCHEMA','const PLUGIN_INDEX_CACHE_SCHEMA')
edit('extensions/pi-claude-marketplace/shared/completion-cache.ts',cache)

def config_tests(s):
 s=s.replace('  CONFIG_VALIDATOR,\n','')
 start=s.index('describe("CONFIG_VALIDATOR"')
 end=s.index('describe("loadConfig"',start)
 block=s[start:end].replace('describe("CONFIG_VALIDATOR"','describe("loadConfig version validation"').replace('() => {\n    // arrange','async (t) => {\n    // arrange')
 block=block.replace('    // act\n    const accepted = CONFIG_VALIDATOR.Check(config);','    const scopeRoot = await mkdtemp(path.join(tmpdir(), "config-io-complete-"));\n    t.after(() => rm(scopeRoot, { recursive: true, force: true }));\n    const filePath = path.join(scopeRoot, "claude-plugins.json");\n    await writeFile(filePath, JSON.stringify(config));\n\n    // act\n    const loadedConfig = await loadConfig(filePath);')
 block=block.replace('    assert.strictEqual(accepted, true);','    assert.deepStrictEqual(loadedConfig, {\n      status: "valid", filePath,\n      config: { schemaVersion: 1, marketplaces: { tools: { source: "acme/tools", autoupdate: true } }, plugins: { "reviewer@tools": { enabled: true } } },\n    });')
 s=s[:start]+block+s[end:]
 start=s.index('  test("uses the no-detail fallback')
 end=s.index('  test("returns the complete ordinary read failure',start)
 return s[:start]+s[end:]
edit('tests/persistence/config-io.test.ts',config_tests)

def cache_tests(s):
 s=s.replace('  MARKETPLACE_NAMES_CACHE_SCHEMA,\n','').replace('  PLUGIN_INDEX_CACHE_SCHEMA,\n','')
 start=s.index('describe("cache schemas"')
 end=s.index('test("omits the unused',start)
 proof='''void ({
  installed: true,
  upgradable: true,
  "partially-installed": true,
  "partially-installed-upgradable": true,
  "partially-upgradable": true,
  available: true,
  "partially-available": true,
  unavailable: true,
  remote: true,
} satisfies Record<PluginIndexRow["status"], true>);

'''
 return s[:start]+proof+s[end:]
edit('tests/shared/completion-cache.test.ts',cache_tests)

def state_tests(s):
 s=s.replace('  STATE_VALIDATOR,\n','').replace('  type EnabledPluginRecord,\n','').replace('satisfies EnabledPluginRecord','satisfies PluginInstallRecord')
 s=s.replace('// @ts-expect-error an enabled record must retain the true discriminant','// @ts-expect-error a stored plugin record requires its complete installation fields')
 start=s.index('for (const { name, state, accepted }')
 end=s.index('test("rejects an unsupported stored',start)
 s=s[:start]+'''for (const { name, state, expectedState } of [
  { name: "schema version 1", state: { schemaVersion: 1, marketplaces: {} }, expectedState: { schemaVersion: 2, marketplaces: {} } },
  { name: "schema version 2", state: { schemaVersion: 2, marketplaces: {} }, expectedState: { schemaVersion: 2, marketplaces: {} } },
  { name: "optional reconciliation stamp", state: { schemaVersion: 2, lastReconciledExtensionVersion: "0.17.0", marketplaces: {} }, expectedState: { schemaVersion: 2, lastReconciledExtensionVersion: "0.17.0", marketplaces: {} } },
]) {
  test(`loads ${name} through the state contract`, async (t) => {
    // arrange
    const extensionRoot = await createExtensionRoot(t, "state-io-version-contract-");
    await writeFile(path.join(extensionRoot, "state.json"), JSON.stringify(state));

    // act
    const loadedState = await loadState(extensionRoot);

    // assert
    assert.deepStrictEqual(loadedState, expectedState);
  });
}

'''+s[end:]
 s=s.replace('test("validates complete hook and resolved-sha plugin records", () => {','test("loads complete hook and resolved-sha plugin records", async (t) => {')
 start=s.index('test("loads complete hook')
 end=s.index('test("returns the exact default',start)
 block=s[start:end].replace('  // act\n  const valid = STATE_VALIDATOR.Check(storedState);','  const extensionRoot = await createExtensionRoot(t, "state-io-complete-record-");\n  await writeFile(path.join(extensionRoot, "state.json"), JSON.stringify(storedState));\n\n  // act\n  const loadedState = await loadState(extensionRoot);').replace('  assert.strictEqual(valid, true);','  assert.deepStrictEqual(loadedState, storedState);')
 s=s[:start]+block+s[end:]
 start=s.index('test("formats a root validator failure')
 end=s.index('test("uses the no-detail fallback',start)
 block=s[start:end].replace('formats a root validator failure through the public loader','rejects a nonobject save without replacing state bytes')
 block=block.replace('  const rootErrors = STATE_VALIDATOR.Errors(null);\n  t.mock.method(STATE_VALIDATOR, "Check", () => false);\n  t.mock.method(STATE_VALIDATOR, "Errors", () => rootErrors);\n','')
 block=block.replace('    () => loadState(extensionRoot),','    // @ts-expect-error an unchecked JavaScript caller can pass a nonobject state\n    () => saveState(extensionRoot, null),')
 block=block.replace('message: `state.json at ${stateJsonPath} failed schema validation: <root>: must be object`,','message: "saveState refused: in-memory state failed schema validation: <root>: must be object",')
 block=block.replace('  );\n});','  );\n  assert.strictEqual(await readFile(stateJsonPath, "utf8"), "{}");\n});')
 s=s[:start]+block+s[end:]
 start=s.index('test("uses the no-detail fallback')
 end=s.index('test("rejects an invalid save',start)
 s=s[:start]+s[end:]
 s=s.replace('test(`rejects ${name} at the published validator`, () => {','test(`rejects ${name} before saving state`, async (t) => {')
 s=s.replace('    // act\n    const valid = STATE_VALIDATOR.Check(storedState);\n\n    // assert\n    assert.strictEqual(valid, false);','''    const extensionRoot = await createExtensionRoot(t, "state-io-invalid-plugin-");
    const stateJsonPath = path.join(extensionRoot, "state.json");
    await writeFile(stateJsonPath, "retain existing state");

    // act & assert
    await assert.rejects(
      // @ts-expect-error malformed persisted records cross an unchecked JavaScript boundary
      () => saveState(extensionRoot, storedState),
      { message: expectedError },
    );
    assert.strictEqual(await readFile(stateJsonPath, "utf8"), "retain existing state");''')
 s=s.replace('for (const { name, plugin } of [','for (const { name, plugin, expectedError } of [')
 for name,error in [('a plugin without hooks','/marketplaces/catalog/plugins/plugin/resources: must have required properties hooks'),('a plugin with non-array hooks','/marketplaces/catalog/plugins/plugin/resources/hooks: must be array'),('a plugin without enabled','/marketplaces/catalog/plugins/plugin: must have required properties enabled')]:
  s=s.replace('    name: "'+name+'",','    name: "'+name+'",\n    expectedError: "saveState refused: in-memory state failed schema validation: '+error+'",')
 return s
edit('tests/persistence/state-io.test.ts',state_tests)
