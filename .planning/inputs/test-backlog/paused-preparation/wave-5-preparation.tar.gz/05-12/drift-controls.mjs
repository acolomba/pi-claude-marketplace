import assert from "node:assert/strict";
import { readFileSync, writeFileSync } from "node:fs";
import { spawnSync } from "node:child_process";

const root = "/tmp/05-12-controls";
const output = "/tmp/05-12-preparation";
const statePath = "extensions/pi-claude-marketplace/persistence/state-io.ts";
const cachePath = "extensions/pi-claude-marketplace/shared/completion-cache.ts";
const originals = new Map([statePath, cachePath].map((path) => [path, readFileSync(`${root}/${path}`, "utf8")]));
const findings = [];
function run(name, args, expectedStatus, diagnostic) {
  const result = spawnSync(process.execPath, args, { cwd: root, encoding: "utf8", maxBuffer: 32 * 1024 * 1024 });
  const text = result.stdout + result.stderr;
  writeFileSync(`${output}/control-${name}.log`, text);
  assert.equal(result.error, undefined);
  assert.equal(result.signal, null);
  assert.equal(result.status, expectedStatus, `${name}: ${text}`);
  if (diagnostic !== undefined) assert.match(text, diagnostic);
  findings.push({name, status:result.status, diagnostic:diagnostic?.source});
}
const compile = ["node_modules/typescript/bin/tsc", "--project", "tsconfig.owner.json", "--pretty", "false"];
run("benign-types", compile, 0);
const state = originals.get(statePath);
const cache = originals.get(cachePath);
try {
  writeFileSync(`${root}/${statePath}`, state.replace("const PLUGIN_INSTALL_RECORD_SCHEMA = Type.Object({", "const PLUGIN_INSTALL_RECORD_SCHEMA = Type.Object({\n  futurePersistedField: Type.Optional(Type.String()),"));
  run("added-persisted-field", compile, 2, /compat-01-no-expansion\.test\.ts\(\d+,\d+\): error TS1360/);
  writeFileSync(`${root}/${statePath}`, state);
  writeFileSync(`${root}/${cachePath}`, cache.replace('| "remote";', '| "remote"\n    | "future-status";'));
  run("added-status", compile, 2, /completion-cache\.test\.ts\(\d+,\d+\): error TS1360/);
  writeFileSync(`${root}/${cachePath}`, cache.replace(/readonly status:[\s\S]*?\| "remote";/u, "readonly status: string;"));
  run("broad-status", compile, 2, /completion-cache\.test\.ts\(\d+,\d+\): error TS1360/);
  writeFileSync(`${root}/${cachePath}`, cache);
  writeFileSync(`${root}/${statePath}`, state.replace("Type.Union([Type.Literal(1), Type.Literal(2)])", "Type.Union([Type.Literal(1), Type.Literal(2), Type.Literal(3)])"));
  run("added-state-version", compile, 2, /compat-01-no-expansion\.test\.ts\(\d+,\d+\): error TS1360/);
  writeFileSync(`${root}/${statePath}`, state);
  writeFileSync(`${root}/${statePath}`, state.replace("hooks: Type.Array(Type.String()),", "hooks: Type.Optional(Type.Array(Type.String())),"));
  run("optional-hook-resource", compile, 2, /hooks-foundation\.test\.ts\(\d+,\d+\): error TS1360/);
  writeFileSync(`${root}/${statePath}`, state);
  const test = ["--test", "tests/persistence/state-io.test.ts"];
  run("benign-serialization", test, 0, /pass 38/);
  writeFileSync(`${root}/${statePath}`, state.replace("await atomicWriteJson(stateJsonPath, state);", "await atomicWriteJson(stateJsonPath, JSON.parse(JSON.stringify(state, (key, value) => key === 'hookEntries' ? undefined : value)));"));
  run("dropped-persisted-field", test, 1, /ERR_ASSERTION/);
} finally {
  for (const [path, text] of originals) writeFileSync(`${root}/${path}`, text);
}
writeFileSync(`${output}/drift-controls.json`, JSON.stringify(findings, null, 2) + "\n");
console.log(JSON.stringify(findings));
