import assert from "node:assert/strict";
import { writeFileSync } from "node:fs";
import { performance } from "node:perf_hooks";
import { CONFIG_VALIDATOR } from "/tmp/05-12-fallow-before/extensions/pi-claude-marketplace/persistence/config-io.ts";
import { STATE_VALIDATOR } from "/tmp/05-12-fallow-before/extensions/pi-claude-marketplace/persistence/state-io.ts";

const configuration = {
  schemaVersion: 1,
  marketplaces: { catalog: { source: "./catalog", autoupdate: true } },
  plugins: { "tool@catalog": { enabled: false } },
};
const state = {
  schemaVersion: 2,
  lastReconciledExtensionVersion: "0.18.3",
  marketplaces: { catalog: {
    name: "catalog", scope: "user",
    source: { kind: "path", raw: "./catalog", logical: "./catalog" },
    addedFromCwd: "/work", manifestPath: "/catalog/marketplace.json", marketplaceRoot: "/catalog",
    plugins: { tool: {
      version: "1", resolvedSource: "/catalog/tool", resolvedSha: "abc",
      hookEntries: [{ event: "PreToolUse", matcher: "Bash" }],
      compatibility: { installable: true, notes: [], supported: [], unsupported: [] },
      resources: { skills: [], prompts: [], agents: [], mcpServers: [], hooks: [] },
      enabled: true, installedAt: "2026-01-01", updatedAt: "2026-01-01",
    } },
  } },
};

function variants(seed) {
  const values = [null, false, true, 0, 1, 2, 3, "", "wrong", [], {}, [0], ["hook"]];
  const out = [...values, seed];
  function walk(value, keys) {
    if (typeof value !== "object" || value === null) return;
    for (const key of Object.keys(value)) {
      const path = [...keys,key];
      for (const replacement of values) {
        const changed = structuredClone(seed);
        const parent = path.slice(0,-1).reduce((record,key) => record[key], changed);
        parent[key] = structuredClone(replacement);
        out.push(changed);
      }
      const removed = structuredClone(seed);
      const parent = path.slice(0,-1).reduce((record,key) => record[key], removed);
      delete parent[key];
      out.push(removed);
      walk(value[key],path);
    }
  }
  walk(seed,[]);
  return out;
}

const reports=[];
for (const [name,validator,seed] of [["config",CONFIG_VALIDATOR,configuration],["state",STATE_VALIDATOR,state]]) {
  const corpus=variants(seed);
  let accepted=0;
  for (const candidate of corpus) {
    const bytes=JSON.stringify(candidate);
    const valid=validator.Check(candidate);
    const errors=validator.Errors(candidate);
    assert.equal(errors.length===0,valid);
    assert.equal(JSON.stringify(candidate),bytes);
    if (valid) accepted++;
    else {
      assert.equal(typeof errors[0].instancePath,"string");
      assert.equal(typeof errors[0].message,"string");
    }
  }
  for (let index=0;index<10000;index++) { validator.Check(seed); validator.Errors(seed); }
  const count=100000;
  let start=performance.now();
  for (let index=0;index<count;index++) validator.Check(seed);
  const checkMs=performance.now()-start;
  start=performance.now();
  for (let index=0;index<count;index++) validator.Errors(seed);
  const errorsMs=performance.now()-start;
  reports.push({name,accelerated:validator.IsAccelerated(),cases:corpus.length,accepted,rejected:corpus.length-accepted,benchmarkIterations:count,checkMs,errorsMs});
}
writeFileSync("/tmp/05-12-preparation/typebox-contract.json",JSON.stringify(reports,null,2)+"\n");
console.log(JSON.stringify(reports));
