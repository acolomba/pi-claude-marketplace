import assert from "node:assert/strict";
import { writeFileSync } from "node:fs";
import { readAnalyzerReport, findingIdentities } from "/home/acolomba/src/pi-claude-marketplace-test-backlog/tests/architecture/fallow-report.ts";

const analyzer = "/home/acolomba/src/pi-claude-marketplace-test-backlog/node_modules/fallow/bin/fallow";
const args = [analyzer, "dead-code", "--no-cache", "--format", "json", "--fail-on-issues"];
const before = readAnalyzerReport(process.execPath, args, "/tmp/05-12-fallow-before");
const after = readAnalyzerReport(process.execPath, args, "/tmp/05-12-fallow-after");
const oldIds = findingIdentities(before.findings);
const newIds = findingIdentities(after.findings);
const removed = oldIds.filter((identity) => !newIds.includes(identity));
const added = newIds.filter((identity) => !oldIds.includes(identity));
assert.deepStrictEqual(removed, [
  "unused_exports|extensions/pi-claude-marketplace/persistence/config-io.ts|CONFIG_VALIDATOR",
  "unused_exports|extensions/pi-claude-marketplace/persistence/state-io.ts|PLUGIN_INSTALL_RECORD_SCHEMA",
  "unused_exports|extensions/pi-claude-marketplace/persistence/state-io.ts|STATE_SCHEMA",
  "unused_exports|extensions/pi-claude-marketplace/persistence/state-io.ts|STATE_VALIDATOR",
  "unused_exports|extensions/pi-claude-marketplace/shared/completion-cache.ts|MARKETPLACE_NAMES_CACHE_SCHEMA",
  "unused_exports|extensions/pi-claude-marketplace/shared/completion-cache.ts|PLUGIN_INDEX_CACHE_SCHEMA",
  "unused_types|extensions/pi-claude-marketplace/persistence/state-io.ts|EnabledPluginRecord",
]);
assert.deepStrictEqual(added, []);
assert.equal(before.totalIssues - after.totalIssues, 7);
assert.deepStrictEqual([before.entryPointCount, after.entryPointCount], [10, 10]);
assert.deepStrictEqual([before.exitStatus, after.exitStatus], [1, 1]);
writeFileSync("/tmp/05-12-preparation/fallow-comparison.json", JSON.stringify({before,after,removed,added},null,2)+"\n");
console.log(JSON.stringify({before:before.totalIssues,after:after.totalIssues,removed,added}));
