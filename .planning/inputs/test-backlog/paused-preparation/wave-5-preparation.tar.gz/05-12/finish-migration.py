from pathlib import Path
import re,shutil,json
r=Path('/tmp/05-12-preparation')

def edit(rel,fn):
 p=r/rel;p.write_text(fn(p.read_text()))

def compatibility(s):
 s=s.replace('  PLUGIN_INSTALL_RECORD_SCHEMA,\n','').replace('  STATE_SCHEMA,\n','')
 anchor='import type { LedgerDegradationSignals }'
 s=s.replace(anchor,'import type { ExtensionState, PluginInstallRecord } from "../../extensions/pi-claude-marketplace/persistence/state-io.ts";\n\n'+anchor)
 start=s.index('test("COMPAT-01: the persisted install record')
 end=s.index('test("COMPAT-01: the install outcome',start)
 s=s[:start]+'''type IsExact<Actual, Expected> = [Actual] extends [Expected]
  ? [Expected] extends [Actual] ? true : false
  : false;

void (true satisfies IsExact<
  keyof PluginInstallRecord,
  "compatibility" | "enabled" | "hookEntries" | "installedAt" | "resolvedSha" |
  "resolvedSource" | "resources" | "updatedAt" | "version"
>);

'''+s[end:]
 start=s.index('test("COMPAT-01: no manifest-snapshot')
 end=s.index('test("COMPAT-01: the default state',start)
 s=s[:start]+'''void (true satisfies IsExact<Extract<
  keyof PluginInstallRecord,
  "manifestSnapshot" | "manifest" | "manifestEntry" | "entry" |
  "orphan" | "orphanRewake" | "orphaned"
>, never>);

void (true satisfies IsExact<ExtensionState["schemaVersion"], 1 | 2>);

'''+s[end:]
 s=s.replace("The state schema's version property still\n *   enumerates exactly the two versions it already enumerated", "The public state's version type still\n *   admits exactly the two versions it already admitted")
 s=s.replace("the eight fields it already had", "the nine fields it already had")
 return s
edit('tests/architecture/compat-01-no-expansion.test.ts',compatibility)

foundation='tests/architecture/hooks-foundation.test.ts'
upstream=Path('/tmp/phase5-11-prepared')/foundation
shutil.copy2(r/'baseline'/foundation,r/'hooks-foundation-checkout-baseline.ts')
shutil.copy2(upstream,r/foundation)
shutil.copy2(upstream,r/'baseline'/foundation)
def hooks(s):
 s=s.replace('import { STATE_SCHEMA } from "../../extensions/pi-claude-marketplace/persistence/state-io.ts";','import type { ExtensionState, PluginInstallRecord } from "../../extensions/pi-claude-marketplace/persistence/state-io.ts";')
 start=s.index('// ─────')
 end=s.index('// ─────',s.index('test("HOOK-02',start)+10)
 s=s[:start]+'''// The actual public state contract keeps exactly both accepted schema versions
// and requires all five resource arrays. Persistence owner tests exercise these
// same fields through loadState/saveState, including invalid records and bytes.
type IsExact<Actual, Expected> = [Actual] extends [Expected]
  ? [Expected] extends [Actual] ? true : false
  : false;

void (true satisfies IsExact<ExtensionState["schemaVersion"], 1 | 2>);
void (true satisfies IsExact<PluginInstallRecord["resources"], {
  skills: string[];
  prompts: string[];
  agents: string[];
  mcpServers: string[];
  hooks: string[];
}>);

'''+s[end:]
 return s
edit(foundation,hooks)

def install(s):
 s=s.replace('  STATE_VALIDATOR,\n','')
 start=s.index('test("orchestrated install reports when the state write')
 end=s.index('test("install forwards explicit',start)
 block=s[start:end]
 block=block.replace('      const parse = t.mock.method(JSON, "parse", (text: string): unknown => {\n        const parsed = originalParse(text);\n        if (STATE_VALIDATOR.Check(parsed)) {','      const seededBytes = await readFile(locations.stateJsonPath, "utf8");\n      const seededState = await loadState(locations.extensionRoot);\n      const parse = t.mock.method(JSON, "parse", (text: string): unknown => {\n        if (text === seededBytes) {\n          const parsed = structuredClone(seededState);')
 block=block.replace('          }\n        }\n\n        return parsed;','          }\n          return parsed;\n        }\n\n        return originalParse(text);')
 s=s[:start]+block+s[end:]
 start=s.index('test("retry proof: install: state commit race')
 block=s[start:]
 block=block.replace('      let eraseFreshRecord = true;','      const seededState = await loadState(locations.extensionRoot);\n      let eraseFreshRecord = true;')
 block=block.replace('        const parsed = originalParse(text);\n        if (eraseFreshRecord && STATE_VALIDATOR.Check(parsed)) {','        if (eraseFreshRecord && text === stateBytes) {\n          const parsed = structuredClone(seededState);')
 block=block.replace('          }\n        }\n\n        return parsed;','          }\n          return parsed;\n        }\n\n        return originalParse(text);')
 return s[:start]+block
edit('tests/orchestrators/plugin/install-flow.test.ts',install)

def cache(s):
 start=s.index('test("omits the unused')
 statuses=['installed','upgradable','partially-installed','partially-installed-upgradable','partially-upgradable','available','partially-available','unavailable','remote']
 status_rows=[{'name':'row-'+str(i+1),'status':status,'version':'1.0'} for i,status in enumerate(statuses)]
 rows=json.dumps(status_rows)
 payload=json.dumps({'schemaVersion':6,'lastRefreshedAt':'2026-08-29T12:00:00.000Z','manifestRef':'main','plugins':status_rows})
 cases=f'''test("hydrates every supported plugin status and retains exact cache bytes", async (t) => {{
  // arrange
  const directory = await mkdtemp(path.join(os.tmpdir(), "completion-all-statuses-"));
  t.after(() => rm(directory, {{ recursive: true, force: true }}));
  const cachePath = path.join(directory, "plugin-index.json");
  const bytes = {json.dumps(payload)};
  await writeFile(cachePath, bytes);
  const cache = createCompletionCache();

  // act
  const rows = await cache.getPluginIndex(cachePath, "user", "catalog", () => Promise.reject(new Error("valid status rebuilt")), {{ now: () => Date.parse("2026-08-29T12:00:00.000Z") }});

  // assert
  assert.deepStrictEqual(rows, {rows});
  assert.strictEqual(await readFile(cachePath, "utf8"), bytes);
}});

'''
 valid={'schemaVersion':6,'lastRefreshedAt':'2026-08-29T12:00:00.000Z','manifestRef':'main','plugins':[{'name':'valid','status':'installed','version':'1'}],'_loadError':'error'}
 invalid=[]
 for key in ['schemaVersion','lastRefreshedAt','plugins']:
  v=valid.copy();v.pop(key);invalid.append({'name':'missing '+key,'bytes':json.dumps(v)})
 for key,value in [('lastRefreshedAt',5),('manifestRef',5),('_loadError',5),('plugins',{})]:
  v=valid.copy();v[key]=value;invalid.append({'name':'invalid '+key,'bytes':json.dumps(v)})
 for key in ['name','status']:
  v=valid.copy();row={'name':'valid','status':'installed','version':'1'};row.pop(key);v['plugins']=[row];invalid.append({'name':'missing row '+key,'bytes':json.dumps(v)})
 for key in ['name','version']:
  v=valid.copy();row={'name':'valid','status':'installed','version':'1'};row[key]=7;v['plugins']=[row];invalid.append({'name':'invalid row '+key,'bytes':json.dumps(v)})
 cases+='for (const { name, bytes } of '+json.dumps(invalid)+''') {
  test(`rebuilds a cache with ${name} into complete current bytes`, async (t) => {
    // arrange
    const directory = await mkdtemp(path.join(os.tmpdir(), "completion-invalid-fields-"));
    t.after(() => rm(directory, { recursive: true, force: true }));
    const cachePath = path.join(directory, "plugin-index.json");
    await writeFile(cachePath, bytes);
    const cache = createCompletionCache();
    const clock = Date.parse("2026-08-29T12:00:00.000Z");
    t.mock.timers.enable({ apis: ["Date"], now: clock });

    // act
    const rows = await cache.getPluginIndex(cachePath, "user", "catalog", () => Promise.resolve([{ name: "rebuilt", status: "available" }]), { now: () => clock });

    // assert
    assert.deepStrictEqual(rows, [{ name: "rebuilt", status: "available" }]);
    assert.strictEqual(await readFile(cachePath, "utf8"), `{
  "schemaVersion": 6,
  "lastRefreshedAt": "2026-08-29T12:00:00.000Z",
  "plugins": [
    {
      "name": "rebuilt",
      "status": "available"
    }
  ]
}
`);
  });
}

'''
 return s[:start]+cases+s[start:]
edit('tests/shared/completion-cache.test.ts',cache)
