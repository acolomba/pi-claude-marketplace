from pathlib import Path

root = Path('/tmp/bridge-composition-prep/prepared')
file = root / 'tests/bridges/hooks/index.test.ts'
contents = file.read_text()
contents = contents.replace('import assert from "node:assert/strict";\n', 'import assert from "node:assert/strict";\nimport { lstat, mkdir, mkdtemp, readFile, readdir, readlink, realpath, rm, symlink, writeFile } from "node:fs/promises";\nimport { tmpdir } from "node:os";\nimport path from "node:path";\n')
contents = contents.replace('  writeHookConfig as definingWriteHookConfig,\n', '')
needle = 'import type * as HooksBarrel'
contents = contents.replace(needle, 'import { locationsFor } from "../../../extensions/pi-claude-marketplace/persistence/locations.ts";\nimport { SymlinkRefusedError } from "../../../extensions/pi-claude-marketplace/shared/path-safety.ts";\n\n' + needle)
start = contents.index('describe("writeHookConfig",')
contents = contents[:start] + '''describe("writeHookConfig", () => {
  test("writes complete hook bytes repeatedly through the Node tree inspector", async (t) => {
    // arrange
    const directory = await mkdtemp(path.join(tmpdir(), "hooks-bridge-compose-"));
    t.after(() => rm(directory, { recursive: true, force: true, maxRetries: 3 }));
    const root = await realpath(directory);
    const locations = locationsFor("project", root);
    const pluginRoot = path.join(root, "plugin");
    const hooksRoot = path.join(pluginRoot, "hooks");
    const nestedRoot = path.join(hooksRoot, "nested");
    const sharedRoot = path.join(pluginRoot, "shared");
    const sourceScript = path.join(nestedRoot, "run.sh");
    const sharedScript = path.join(sharedRoot, "shared.sh");
    const linkPath = path.join(hooksRoot, "shared-link");
    await mkdir(nestedRoot, { recursive: true });
    await mkdir(sharedRoot);
    await writeFile(sourceScript, "echo source\\n");
    await writeFile(sharedScript, "echo shared\\n");
    await symlink(sharedRoot, linkPath, process.platform === "win32" ? "junction" : "dir");
    const expectedPath = path.join(locations.hooksDir, "acme", "hooks.json");
    const hooksValue = { Stop: [{ hooks: [{ type: "command", command: "echo ready" }] }] };
    const expectedBytes = `{
  "Stop": [
    {
      "hooks": [
        {
          "type": "command",
          "command": "echo ready"
        }
      ]
    }
  ]
}
`;

    // act
    const writtenHook = await writeHookConfig({ locations, pluginName: "acme", pluginRoot, hooksValue });
    const firstBytes = await readFile(expectedPath, "utf8");
    const repeatedHook = await writeHookConfig({ locations, pluginName: "acme", pluginRoot, hooksValue });
    const repeatedBytes = await readFile(expectedPath, "utf8");

    // assert
    assert.deepStrictEqual(writtenHook, { written: true, path: expectedPath });
    assert.deepStrictEqual(repeatedHook, { written: true, path: expectedPath });
    assert.strictEqual(firstBytes, expectedBytes);
    assert.strictEqual(repeatedBytes, expectedBytes);
    assert.deepStrictEqual(await readdir(path.dirname(expectedPath)), ["hooks.json"]);
    assert.deepStrictEqual((await readdir(hooksRoot)).sort(), ["nested", "shared-link"]);
    assert.strictEqual(await readFile(sourceScript, "utf8"), "echo source\\n");
    assert.strictEqual(await readFile(sharedScript, "utf8"), "echo shared\\n");
    assert.strictEqual((await lstat(linkPath)).isSymbolicLink(), true);
  });

  test("refuses an escaping source symlink before replacing staged or external bytes", async (t) => {
    // arrange
    const directory = await mkdtemp(path.join(tmpdir(), "hooks-bridge-escape-"));
    t.after(() => rm(directory, { recursive: true, force: true, maxRetries: 3 }));
    const root = await realpath(directory);
    const locations = locationsFor("project", root);
    const pluginRoot = path.join(root, "plugin");
    const hooksRoot = path.join(pluginRoot, "hooks");
    const externalRoot = path.join(root, "external");
    const externalFile = path.join(externalRoot, "keep.txt");
    const linkPath = path.join(hooksRoot, "escape");
    const stagedPath = path.join(locations.hooksDir, "acme", "hooks.json");
    await mkdir(hooksRoot, { recursive: true });
    await mkdir(externalRoot);
    await mkdir(path.dirname(stagedPath), { recursive: true });
    await writeFile(externalFile, "external bytes\\n");
    await writeFile(stagedPath, '{"retained":true}\\n');
    await symlink(externalRoot, linkPath, process.platform === "win32" ? "junction" : "dir");
    const expectedLinkTarget = await readlink(linkPath);

    // act
    const writeError: unknown = await writeHookConfig({
      locations,
      pluginName: "acme",
      pluginRoot,
      hooksValue: { replacement: true },
    }).then(() => undefined, (error: unknown) => error);

    // assert
    assert.ok(writeError instanceof SymlinkRefusedError);
    assert.deepStrictEqual(
      { name: writeError.name, message: writeError.message, parent: writeError.parent, child: writeError.child, linkPath: writeError.linkPath, linkTarget: writeError.linkTarget, cause: writeError.cause },
      {
        name: "SymlinkRefusedError",
        message: `hooks subtree symlink ${linkPath} contains symlink ${linkPath} -> ${expectedLinkTarget} (parent: ${pluginRoot}, target: ${externalRoot}).`,
        parent: pluginRoot,
        child: externalRoot,
        linkPath,
        linkTarget: expectedLinkTarget,
        cause: undefined,
      },
    );
    assert.strictEqual(await readFile(stagedPath, "utf8"), '{"retained":true}\\n');
    assert.strictEqual(await readFile(externalFile, "utf8"), "external bytes\\n");
    assert.deepStrictEqual(await readdir(path.dirname(stagedPath)), ["hooks.json"]);
    assert.deepStrictEqual(await readdir(externalRoot), ["keep.txt"]);
    assert.strictEqual((await lstat(linkPath)).isSymbolicLink(), true);
    assert.strictEqual(await readlink(linkPath), expectedLinkTarget);
  });
});
'''
file.write_text(contents)

file = root / 'tests/bridges/skills/index.test.ts'
contents = file.read_text()
contents = contents.replace('import assert from "node:assert/strict";\n', 'import assert from "node:assert/strict";\nimport { mkdir, mkdtemp, readFile, readdir, rm, writeFile } from "node:fs/promises";\nimport { tmpdir } from "node:os";\nimport path from "node:path";\n')
contents = contents.replace('import { unstagePluginSkills as definingUnstagePluginSkills } from "../../../extensions/pi-claude-marketplace/bridges/skills/unstage.ts";\n', 'import { locationsFor } from "../../../extensions/pi-claude-marketplace/persistence/locations.ts";\n')
start = contents.index('describe("unstagePluginSkills",')
contents = contents[:start] + '''describe("unstagePluginSkills", () => {
  test("removes only recorded trees and retries missing names through the Node remover", async (t) => {
    // arrange
    const root = await mkdtemp(path.join(tmpdir(), "skills-bridge-remove-"));
    t.after(() => rm(root, { recursive: true, force: true, maxRetries: 3 }));
    const locations = locationsFor("project", root);
    const firstDirectory = path.join(locations.skillsTargetDir, "acme-first");
    const secondDirectory = path.join(locations.skillsTargetDir, "acme-second");
    const foreignDirectory = path.join(locations.skillsTargetDir, "foreign-keep");
    const foreignFile = path.join(foreignDirectory, "SKILL.md");
    await mkdir(path.join(firstDirectory, "resources"), { recursive: true });
    await mkdir(secondDirectory);
    await mkdir(foreignDirectory);
    await writeFile(path.join(firstDirectory, "resources", "nested.json"), '{"nested":true}\\n');
    await writeFile(path.join(secondDirectory, "SKILL.md"), "second skill bytes\\n");
    await writeFile(foreignFile, "foreign skill bytes\\n");
    const previousSkillNames = ["acme-second", "acme-missing", "acme-first"];

    // act
    const removedSkills = await unstagePluginSkills({ locations, previousSkillNames });
    const remainingNames = await readdir(locations.skillsTargetDir);
    const repeatedRemoval = await unstagePluginSkills({ locations, previousSkillNames });

    // assert
    assert.deepStrictEqual(removedSkills, { removedNames: ["acme-second", "acme-first"], warnings: [] });
    assert.deepStrictEqual(repeatedRemoval, { removedNames: [], warnings: [] });
    assert.strictEqual(Object.isFrozen(removedSkills.removedNames), true);
    assert.strictEqual(Object.isFrozen(removedSkills.warnings), true);
    assert.strictEqual(Object.isFrozen(repeatedRemoval.removedNames), true);
    assert.strictEqual(Object.isFrozen(repeatedRemoval.warnings), true);
    assert.deepStrictEqual(remainingNames, ["foreign-keep"]);
    assert.deepStrictEqual(await readdir(locations.skillsTargetDir), ["foreign-keep"]);
    assert.strictEqual(await readFile(foreignFile, "utf8"), "foreign skill bytes\\n");
  });
});
'''
file.write_text(contents)
