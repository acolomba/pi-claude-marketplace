# Plan 05-07 preparation and assertion ledger

Status: prepared entirely under `/tmp/bridge-composition-prep`; checkout remains untouched by this executor. The final hooks/skills owner baselines include the parent-reviewed seven strengthened type-absence checks. Explicit GO and baseline hash verification are required before applying.

## Scope and artifacts

Eight planned source/owner files only, captured in `base-hashes.json` and `changes.json`. `05-07.patch` is an ordinary unified patch; `prepared/` contains its final full-file payloads and `base/` the reviewed baselines. `test-body-ledger.json` contains every original/retained/added test name, SHA-256 of every retained complete test body, and the full bodies of removed and added cases. `audit.mjs` independently parses TypeScript test calls to produce that ledger. `TASK-AMENDMENT.md` explains the bounded assertion migrations; no source-path expansion is needed.

## Actual production caller evidence

CodeGraph traced `writeHookConfig`, `createWriteHookConfig`, `unstagePluginSkills`, and `createUnstagePluginSkills` before source investigation. The named direct-import follow-up found no production consumer importing the retired convenience bindings from `hooks/stage.ts` or `skills/unstage.ts`.

| Production operation | Real consumers | Consumer import before and after |
| --- | --- | --- |
| writeHookConfig | install-outcome.ts, update-swap.ts, reinstall-replace.ts | Existing hooks/index.ts public bridge |
| unstagePluginSkills | install-outcome.ts, marketplace/shared.ts | Existing skills/index.ts public bridge |
| createWriteHookConfig | New concrete composition in existing hooks/index.ts | Direct import from stage.ts; called with the same four Node callbacks |
| createUnstagePluginSkills | New concrete composition in existing skills/index.ts | Direct import from unstage.ts; called with the same Node recursive/force remover |

The Node adapters were moved without changing their bodies. Construction performs no filesystem operation. Factories and consumer-declared inspector/remover contracts stay in their coherent implementation owners. No unrelated public runtime/type export changed. The retired direct stage/unstage conveniences have no real caller requiring a compatibility alias.

## Exact finding dispositions

Isolated command, before and after: `node_modules/.bin/fallow dead-code --production --format json --no-cache` in `runtime/`. Fallow 3.22.0, kind dead-code, schema 9; ten entry points in both reports (one manual and nine package.json). Both analyzer runs exit 1 because the isolated project still has outstanding phase findings. That expected diagnostic exit is not represented as a clean analyzer pass.

| Category | Path | Identity | Disposition and evidence |
| --- | --- | --- | --- |
| unused_exports | extensions/pi-claude-marketplace/bridges/hooks/stage.ts | hookConfigPathFor | Private; existing write and remove operations continue using the same path composer. Exact returned path and file bytes remain asserted through public writes. |
| unused_exports | extensions/pi-claude-marketplace/bridges/hooks/stage.ts | createWriteHookConfig | Retain exported factory with real production composition caller hooks/index.ts, preserving the injected tree inspection contract. |
| unused_exports | extensions/pi-claude-marketplace/bridges/skills/unstage.ts | createUnstagePluginSkills | Retain exported factory with real production composition caller skills/index.ts, preserving the injected remover contract. |

Final isolated comparison: 42 to 39 findings, exactly the three identities above removed and zero identities added. `finding-delta.json` records them. No new orphan type, unused import, duplicate export, suppression, or private-type-leak finding appears. Reports are `fallow-before-final.json` (runtime-baseline/) and `fallow-after-final.json` (runtime/). The earlier 41-to-38 reports predate the parent's RingBuffer annotation retirement and are superseded. No RingBuffer change is in this patch. This is evidence about the isolated snapshot, not the parent's live census pin.

## Every removed assertion

| Original test/contract | Replacement public observation | Evidence |
| --- | --- | --- |
| hooks/stage: `composes the staged hook config path`; `assert.strictEqual(hookConfigPath, path.join(locations.hooksDir, PLUGIN, "hooks.json"))` | Existing unchanged full-write owner compares the whole `{written:true,path}` and exact JSON bytes. New bridge success/repeat case independently constructs `path.join(locations.hooksDir, "acme", "hooks.json")`, compares both whole returned values, and reads exact bytes at that path twice. | Composer remains used by real writer/remover; stage direct B34/F9/L287 all hit/found equal. |
| hooks/index: `writeHookConfig / re-exports the defining binding`; strict identity to removed stage convenience | Existing bridge now owns concrete construction. New success/repeat and escape cases call only bridge writeHookConfig and assert full results, bytes, error structure and state listed below. | All four real inspector callbacks exercised; bridge direct B5/F4/L41 all hit/found equal. |
| skills/index: `unstagePluginSkills / re-exports the defining binding`; strict identity to removed unstage convenience | Existing bridge now owns concrete construction. New real-removal case asserts complete ordered result, missing retry, frozen arrays, final tree and foreign bytes listed below. | Real Node removeTree exercised; bridge direct B2/F1/L36 all hit/found equal. |

Exactly three old cases are replaced by three public cases. The total focused count remains 40. No nonredundant behavior assertion is discarded.

## New public composition observations

Hook success/repeat:

- A real temporary plugin has a nested script and an in-tree symlink to a shared directory. Both write calls return exactly `{ written: true, path: expectedPath }`.
- Both complete output strings equal an independently written pretty JSON literal with its trailing newline. Target directory listing is exactly `["hooks.json"]`, detecting atomic temporary-file leftovers.
- Original hooks directory names, full nested/shared script bytes, and symlink state remain unchanged. This reaches the concrete Node lstat, readdir, and realpath callbacks.

Hook escaping symlink:

- An escaping symlink rejects with `SymlinkRefusedError`; the complete selected public error fields are compared: name, exact message, parent, child, linkPath, linkTarget, and cause. The expected link target comes from independently observing the OS symlink representation, not from the writer's result or formatter.
- Previously staged bytes remain exactly `{"retained":true}\n`; external file bytes remain exactly `external bytes\n`. Staged/external directory listings and the source symlink/target remain unchanged.
- This refusal reaches the fourth concrete Node inspector callback, readlink. Existing injected readlink/realpath/directory/lstat failure cases remain in the stage owner unchanged.

Skill removal:

- Real nested trees are created for acme-first and acme-second; the input records second, a missing name, then first. The whole first result is `{ removedNames: ["acme-second", "acme-first"], warnings: [] }`; repeat is `{ removedNames: [], warnings: [] }`.
- Both arrays of both results are frozen. The implementation does not promise a frozen outer object, so no such new contract is invented.
- After the first and repeated calls the target directory contains only foreign-keep, whose full SKILL.md bytes remain `foreign skill bytes\n`.
- Existing injected ENOENT-after-removal and other-error-after-earlier-effects cases retain exact outcomes and interaction order in the unstage owner.

## Retained compiler and runtime proofs

Every pre-existing unrelated runtime binding proof remains byte-for-byte unchanged: four hooks bridge cases and seven skills bridge cases. Every existing hooks stage test except the redundant path composer case (19 retained cases) and all seven skills unstage cases retain their complete original test-call source, including assertions, failure values, lifecycle cleanup and interaction ordering. See the generated per-case list below and JSON SHA-256 evidence.

All existing barrel type assignability, exact public keys, private helper negatives, and type-only proofs remain. The five hooks and two skills repaired absence checks are preserved exactly as `void ({} satisfies { readonly retired?: Barrel.Type })`; they are part of the parent-approved baseline and introduce no additional plan finding/disposition. The interim `| undefined` formulation compiled but produced seven no-redundant-type-constituents lint errors; it was superseded by the parent's independently qualified optional-property formulation, without a cast or rule suppression.

## Verification

All commands execute in the isolated runtime. Meaningful native tests ran with escalated execution because sandbox file-only reporting is not accepted as test discovery.

| Command | Result | Evidence |
| --- | --- | --- |
| node --test tests/bridges/hooks/stage.test.ts tests/bridges/hooks/index.test.ts tests/bridges/skills/unstage.test.ts tests/bridges/skills/index.test.ts | Final optional-property baseline: 40 actual cases, 13 suites, all pass; no skips/todos/failures | focused-final.log |
| node --test tests/bridges/hooks/stage.test.ts tests/bridges/hooks/index.test.ts | 25 actual cases, 5 suites, all pass; repeated in final 40-case command after type-only rebase | task1-final.log |
| node --test tests/bridges/skills/unstage.test.ts tests/bridges/skills/index.test.ts | 15 actual cases, 8 suites, all pass; repeated in final 40-case command after type-only rebase | task2-final.log |
| npm run typecheck | Exit 0 on the final optional-property baseline | typecheck-final.log |
| node node_modules/eslint/bin/eslint.js [eight scoped paths] | Exit 0 on all eight final prepared files | lint-final.log |
| Installed Prettier API `check`, parser typescript, printWidth 100 | All eight final prepared files pass | Recorded tool result: checked 8, failed [] |

Each exact `npm run test:coverage:direct -- <one source path>` was run separately, as the direct CLI requires. The first attempt supplied four paths and was rejected by CLI usage validation; it did not execute tests or provide evidence. The corrected sequential run exits 0:

| Exact source owner | Branches | Functions | Lines |
| --- | --- | --- | --- |
| bridges/hooks/stage.ts | 34/34 | 9/9 | 287/287 |
| bridges/hooks/index.ts | 5/5 | 4/4 | 41/41 |
| bridges/skills/unstage.ts | 11/11 | 2/2 | 67/67 |
| bridges/skills/index.ts | 2/2 | 1/1 | 36/36 |

Full log: direct.log. No coverage pin, source exclusion, test discovery rule, or aggregate threshold changed. Parent-owned full census/native aggregate/precommit/review remain pending after application and writer freeze. No claim of aggregate coverage is made from direct owner coverage.

## Self-check and pending integration

No checkout source/planning/config/index/Git writes, package installation, new production module, test-only production export, blanket analyzer exception, or token estimate disguised as actuals. Eight baseline and prepared files are required and will be hash-checked before GO application. The new tests use per-case temporary roots with registered cleanup and perform no network calls or repository/home writes.

Final type/lint/focused commands pass. All eight baseline SHA-256 hashes match the parent-declared final checkout snapshot; all retained-test body hashes match; all eight prepared files pass formatting; `patch --dry-run -p1` succeeds for all eight files in the isolated baseline copy. Parent owns final snapshot acceptance, live census update, full native aggregate 100% validation, and commits.

Self-check: PASSED for preparation. No checkout application or integration completion is claimed. Ready for explicit GO.

## Per-case unchanged test-body evidence


### tests/bridges/skills/index.test.ts

- abortPreparedSkills / re-exports the defining binding — unchanged full test body
- commitPreparedSkills / re-exports the defining binding — unchanged full test body
- discoverPluginSkills / re-exports the defining binding — unchanged full test body
- finalizeSkillsReplacement / re-exports the defining binding — unchanged full test body
- prepareStageSkills / re-exports the defining binding — unchanged full test body
- replacePreparedSkills / re-exports the defining binding — unchanged full test body
- rollbackSkillsReplacement / re-exports the defining binding — unchanged full test body

### tests/bridges/skills/unstage.test.ts

- removes recorded skill trees in order and preserves foreign bytes — unchanged full test body
- returns an empty result when no skill names were recorded — unchanged full test body
- makes repeated unstaging a missing-directory fixed point — unchanged full test body
- rejects an unsafe recorded name before changing the target tree — unchanged full test body
- rejects a symlinked skill target and preserves its destination — unchanged full test body
- continues after the required remover reports ENOENT after deletion — unchanged full test body
- propagates the required remover failure after earlier effects — unchanged full test body

### tests/bridges/hooks/index.test.ts

- createHooksHydration / re-exports the defining binding — unchanged full test body
- createHooksRuntime / re-exports the lifecycle owner factory — unchanged full test body
- readHooksJson / re-exports the defining binding — unchanged full test body
- removeHookConfig / re-exports the defining binding — unchanged full test body

### tests/bridges/hooks/stage.test.ts

- writes when the plugin hooks subtree is absent — unchanged full test body
- writes when the plugin hooks path is not a directory — unchanged full test body
- walks ordinary nested hook directories without changing their files — unchanged full test body
- treats an in-tree directory link as a safe traversal boundary — unchanged full test body
- rejects a direct directory link that escapes the plugin root — unchanged full test body
- rejects a buried directory link that escapes the plugin root — unchanged full test body
- uses the unreadable target marker when the required inspector cannot read the link — unchanged full test body
- preserves an in-tree symlink refusal when a resolved target becomes a link — unchanged full test body
- propagates a path walk failure caused by a resolved target replacement — unchanged full test body
- propagates an unexpected hook directory read failure unchanged — unchanged full test body
- propagates an unexpected hook entry inspection failure unchanged — unchanged full test body
- writes hooks.json and returns its absolute path — unchanged full test body
- writes the same bytes when the hook config is staged twice — unchanged full test body
- removes an existing staged plugin directory — unchanged full test body
- treats removal of an absent staged plugin as a no-op — unchanged full test body
- rejects an unsafe plugin name before writing — unchanged full test body
- rejects an unsafe plugin name before removal — unchanged full test body
- reads back the exact bytes written to a hooks.json path — unchanged full test body
- rejects when the hooks.json path does not exist — unchanged full test body
