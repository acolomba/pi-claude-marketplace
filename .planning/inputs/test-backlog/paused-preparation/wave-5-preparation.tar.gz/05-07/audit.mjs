import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import ts from '/home/acolomba/src/pi-claude-marketplace-test-backlog/node_modules/typescript/lib/typescript.js';

const root = '/tmp/bridge-composition-prep';
const hashes = JSON.parse(fs.readFileSync(path.join(root, 'base-hashes.json'), 'utf8'));
const hash = text => crypto.createHash('sha256').update(text).digest('hex');
function tests(source) {
  const file = ts.createSourceFile('owner.ts', source, ts.ScriptTarget.Latest, true);
  const found = new Map();
  function visit(node, context = []) {
    if (ts.isCallExpression(node) && ts.isIdentifier(node.expression) &&
        ['test', 'describe'].includes(node.expression.text) &&
        node.arguments[0] && ts.isStringLiteral(node.arguments[0])) {
      const name = [...context, node.arguments[0].text];
      if (node.expression.text === 'test') {
        found.set(name.join(' / '), node.getText(file));
      } else {
        ts.forEachChild(node, child => visit(child, name));
        return;
      }
    }
    ts.forEachChild(node, child => visit(child, context));
  }
  visit(file);
  return found;
}
const ledger = [];
const changes = [];
for (const [file, beforeHash] of Object.entries(hashes)) {
  const before = fs.readFileSync(path.join(root, 'base', file), 'utf8');
  const after = fs.readFileSync(path.join(root, 'prepared', file), 'utf8');
  if (hash(before) !== beforeHash) throw Error(`Bad baseline ${file}`);
  changes.push({path: file, before_sha256: beforeHash, after_sha256: hash(after), content: after});
  if (!file.endsWith('.test.ts')) continue;
  const oldTests = tests(before);
  const newTests = tests(after);
  ledger.push({file, before_count: oldTests.size, after_count: newTests.size,
    retained: [...oldTests].filter(([name]) => newTests.has(name)).map(([name, text]) => ({name, unchanged: text === newTests.get(name), before_sha256: hash(text), after_sha256: hash(newTests.get(name))})),
    removed: [...oldTests].filter(([name]) => !newTests.has(name)).map(([name, text]) => ({name, source: text})),
    added: [...newTests].filter(([name]) => !oldTests.has(name)).map(([name, text]) => ({name, source: text})),
  });
}
fs.writeFileSync(path.join(root, 'changes.json'), JSON.stringify(changes, null, 2) + '\n');
fs.writeFileSync(path.join(root, 'test-body-ledger.json'), JSON.stringify(ledger, null, 2) + '\n');
const before = JSON.parse(fs.readFileSync(path.join(root, 'fallow-before-final.json'), 'utf8'));
const after = JSON.parse(fs.readFileSync(path.join(root, 'fallow-after-final.json'), 'utf8'));
function identities(report) {
  return Object.entries(report).flatMap(([category, rows]) => Array.isArray(rows) && !['next_steps'].includes(category)
    ? rows.map(row => JSON.stringify([category, row.path, row.export_name ?? row.name ?? row.member_name ?? '', row.kind ?? ''])) : []);
}
const oldIds = new Set(identities(before));
const newIds = new Set(identities(after));
const delta = {before:before.total_issues, after:after.total_issues, version:after.version, schema_version:after.schema_version, entry_points:after.entry_points,
 removed:[...oldIds].filter(id=>!newIds.has(id)).map(JSON.parse), added:[...newIds].filter(id=>!oldIds.has(id)).map(JSON.parse)};
fs.writeFileSync(path.join(root, 'finding-delta.json'), JSON.stringify(delta,null,2)+'\n');
console.log(JSON.stringify({tests: ledger.map(({file,before_count,after_count,retained,removed,added})=>({file,before_count,after_count,retained_unchanged:retained.filter(t=>t.unchanged).length,changed:retained.filter(t=>!t.unchanged),removed:removed.map(t=>t.name),added:added.map(t=>t.name)})),delta},null,2));
