from pathlib import Path
import hashlib
import json

root = Path('/tmp/bridge-composition-prep')
checkout = Path('/home/acolomba/src/pi-claude-marketplace-test-backlog')
hashes = json.loads((root / 'base-hashes.json').read_text())
replacements = {
    'tests/bridges/hooks/index.test.ts': [
        (f'void (undefined satisfies HooksBarrel.{name} | undefined);',
         f'void ({{}} satisfies {{ readonly retired?: HooksBarrel.{name} }});')
        for name in ['HooksFileReader', 'HooksHydration', 'HooksHydrationDeps',
                     'ReadAndCachePluginHooksOptions', 'HooksRuntime']
    ],
    'tests/bridges/skills/index.test.ts': [
        (f'void (undefined satisfies SkillsBarrel.{name} | undefined);',
         f'void ({{}} satisfies {{ readonly retired?: SkillsBarrel.{name} }});')
        for name in ['PreparedSkillsStaged', 'StageSkillsCommitResult']
    ],
}
for file, changes in replacements.items():
    before = (root / 'base' / file).read_text()
    prepared = (root / 'prepared' / file).read_text()
    for old, new in changes:
        assert before.count(old) == 1, (file, old)
        assert prepared.count(old) == 1, (file, old)
        before = before.replace(old, new)
        prepared = prepared.replace(old, new)
    assert before == (checkout / file).read_text(), f'Unexpected baseline delta: {file}'
    (root / 'base' / file).write_text(before)
    (root / 'prepared' / file).write_text(prepared)
    (root / 'runtime' / file).write_text(prepared)
    hashes[file] = hashlib.sha256(before.encode()).hexdigest()
(root / 'base-hashes.json').write_text(json.dumps(hashes, indent=2) + '\n')
print('Preserved all seven strengthened parent-owned type-absence checks.')
