**Exploration: writeHookConfig unstagePluginSkills createWriteHookConfig createUnstagePluginSkills production callers install-outcome update-swap reinstall-replace marketplace/shared**

Found 121 symbols across 6 files. 3 files pinned from the query.

**Blast radius — what depends on these (update/verify before editing)**

- `createWriteHookConfig` (extensions/pi-claude-marketplace/bridges/hooks/stage.ts:242) — 2 callers in `extensions/pi-claude-marketplace/bridges/hooks/stage.ts`; tests: `tests/bridges/hooks/stage.test.ts`
- `MarketplaceRows` (extensions/pi-claude-marketplace/shared/notify-context.ts:110) — 45 callers in `extensions/pi-claude-marketplace/orchestrators/import/execute.ts`, `extensions/pi-claude-marketplace/orchestrators/marketplace/add.ts`, `extensions/pi-claude-marketplace/orchestrators/marketplace/autoupdate.ts`, `extensions/pi-claude-marketplace/orchestrators/marketplace/list.ts` +11 more; tests: `tests/shared/notify-context.test.ts`, `tests/orchestrators/plugin/list-orphan-fold.test.ts`
- `MarketplaceDetails` (extensions/pi-claude-marketplace/shared/notification-types.ts:136) — 5 callers in `extensions/pi-claude-marketplace/shared/notification-grammar.ts`, `extensions/pi-claude-marketplace/shared/notification-types.ts`; tested via callers: `tests/architecture/compat-01-no-expansion.test.ts`, `tests/shared/notification-grammar.test.ts`
- `unstagePluginSkills` (extensions/pi-claude-marketplace/bridges/skills/unstage.ts:35) — 6 callers in `extensions/pi-claude-marketplace/orchestrators/plugin/install-outcome.ts`, `extensions/pi-claude-marketplace/orchestrators/marketplace/shared.ts`; tests: `tests/bridges/skills/unstage.test.ts`, `tests/bridges/skills/index.test.ts`

**Relationships**

**references:**
- createWriteHookConfig → writeHookConfig
- createWriteHookConfig → HooksTreeInspector
- createWriteHookConfig → WriteHookConfigInput
- createWriteHookConfig → WriteHookConfigResult
- writeHookConfig → WriteHookConfigInput
- writeHookConfig → WriteHookConfigResult
- writeHookConfig → NODE_HOOKS_TREE_INSPECTOR
- assertNoSymlinkEscapeInHooksSubtree → HooksTreeInspector
- readEntriesOrSkip → HooksTreeInspector
- assertSymlinkEntryContained → HooksTreeInspector
- ... and 125 more

**calls:**
- writeHookConfig → assertNoSymlinkEscapeInHooksSubtree
- writeHookConfig → hookConfigPathFor
- writeHookConfig → atomicWriteJson
- writeHookConfig → assertSafeName
- writeHookConfig → assertPathInside
- runInstallLedgerBody → writeHookConfig
- commitUpdateHooks → writeHookConfig
- observeReinstallOperations → writeHookConfig
- assertNoSymlinkEscapeInHooksSubtree → readEntriesOrSkip
- assertNoSymlinkEscapeInHooksSubtree → assertSymlinkEntryContained
- ... and 87 more


