from pathlib import Path
root=Path('/tmp/phase5-15-prepared')
moved=(root/'moved-concrete-case.ts.txt').read_text()
moved=moved.replace('async () => {\n  await withHermeticHome(async () => {','async (t) => {\n  t.mock.timers.enable({ apis: ["Date"], now: Date.UTC(2026, 0, 1) });\n  await withHermeticEnvironment("install-operation-", async () => {',1)
moved=moved.replace('createNodeInstallPlugin','createInstallOperation').replace('      await runtimeInstallPlugin({','      const outcome = await runtimeInstallPlugin({')
moved=moved.replace('      // Confirm install succeeded', '''      assert.deepStrictEqual(outcome, {
        status: "installed",
        version: "0.0.1",
        resourcesChanged: false,
        declaresAgents: false,
        declaresMcp: false,
      });

      // Confirm install succeeded''')
moved=moved.replace('      assert.deepStrictEqual(peerRuntime.getRoutingBucket("PreToolUse"), []);', '''      assert.deepStrictEqual(peerRuntime.getRoutingBucket("PreToolUse"), []);
      assert.deepStrictEqual(afterState.marketplaces["mp"]?.plugins["p1"], {
        version: "0.0.1",
        resolvedSource: path.join(cwd, "mp-src", "plugins", "p1"),
        compatibility: { installable: true, notes: [], supported: ["hooks"], unsupported: [] },
        resources: { skills: [], prompts: [], agents: [], mcpServers: [], hooks: ["p1"] },
        hookEntries: [{ event: "PreToolUse", matcher: "" }],
        enabled: true,
        installedAt: "2026-01-01T00:00:00.000Z",
        updatedAt: "2026-01-01T00:00:00.000Z",
      });
      assert.strictEqual(
        await readFile(path.join(locations.hooksDir, "p1", "hooks.json"), "utf8"),
        '{\\n  "PreToolUse": [\\n    {\\n      "matcher": "",\\n      "hooks": [\\n        {\\n          "type": "command",\\n          "command": "echo hello"\\n        }\\n      ]\\n    }\\n  ]\\n}\\n',
      );''')
p=root/'tests/orchestrators/plugin/operations.test.ts';p.write_text(p.read_text()+'\n'+moved)
