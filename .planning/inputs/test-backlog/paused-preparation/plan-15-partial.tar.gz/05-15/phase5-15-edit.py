from pathlib import Path
import json,re
root=Path('/tmp/phase5-15-prepared')
files=json.loads((root/'owned-paths.json').read_text())
source='extensions/pi-claude-marketplace/orchestrators/plugin/install-flow.ts'
test='tests/orchestrators/plugin/install-flow.test.ts'
s=(root/source).read_text()
s=s.replace('import { runPhases }','import type { runPhases }').replace('import { withLockedStateTransaction }','import type { withLockedStateTransaction }')
s=re.sub(r'const REAL_INSTALL_TRANSACTION: InstallTransaction = \{.*?\n\};\n\n','',s,flags=re.S)
s=s[:s.index('/** Bind production install behavior to required routing and completion-cache owners. */')]
(root/source).write_text(s)
original=(root/test).read_text()
start=original.index('test("WR-03: installPlugin of a hooks-declaring plugin rebuilds')
end=original.index('\n// ─',start)
moved=original[start:end]
(root/'moved-concrete-case.ts.txt').write_text(moved)
updated=original[:start]+original[end:]
updated=updated.replace('  createNodeInstallPlugin,\n','').replace('ReturnType<typeof createNodeInstallPlugin>','ReturnType<typeof createInstallPlugin>')
(root/test).write_text(updated)
for name in files:
    p=root/name
    if name in [source,test] or not p.exists():continue
    s=p.read_text()
    if 'createNodeInstallPlugin' not in s:continue
    # Split the one mixed runtime/type import; all other callers import only the factory.
    s=s.replace('import {\n  createNodeInstallPlugin,\n  type InstallPluginOptions,\n} from "../../orchestrators/plugin/install-flow.ts";', 'import type { InstallPluginOptions } from "../../orchestrators/plugin/install-flow.ts";\nimport { createInstallOperation } from "../../orchestrators/plugin/operations.ts";')
    s=re.sub(r'(import \{ )createNodeInstallPlugin( \} from "[^"]*)/install-flow.ts";',r'\1createInstallOperation\2/operations.ts";',s)
    s=s.replace('createNodeInstallPlugin','createInstallOperation')
    p.write_text(s)
(root/'extensions/pi-claude-marketplace/orchestrators/plugin/operations.ts').write_text('''import { runPhases } from "../../transaction/phase-ledger.ts";
import { withLockedStateTransaction } from "../../transaction/with-state-guard.ts";

import { createInstallPlugin, type InstallTransaction } from "./install-flow.ts";

import type { InstallHooksRouting } from "./install-disable-cascade.ts";
import type { CompletionCache } from "../../shared/completion-cache.ts";

const INSTALL_TRANSACTION: InstallTransaction = {
  runPhases: (...args) => runPhases(...args),
  withLockedStateTransaction: (...args) => withLockedStateTransaction(...args),
};

/** Composes install with real transaction operations and the caller's routing and cache owners. */
export function createInstallOperation(
  hooksRouting: InstallHooksRouting,
  completionCache: CompletionCache,
): ReturnType<typeof createInstallPlugin> {
  return createInstallPlugin(INSTALL_TRANSACTION, hooksRouting, completionCache);
}
''')
print('Prepared composition and caller migration; concrete case saved for new owner.')
