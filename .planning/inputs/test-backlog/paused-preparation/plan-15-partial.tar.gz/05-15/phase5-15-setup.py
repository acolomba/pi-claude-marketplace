from pathlib import Path
import shutil,json,hashlib,re
repo=Path('/home/acolomba/src/pi-claude-marketplace-test-backlog')
root=Path('/tmp/phase5-15-prepared')
root.mkdir(exist_ok=True)
for directory in ['extensions','tests','scripts']:
    shutil.copytree(repo/directory,root/directory,dirs_exist_ok=True)
for name in ['package.json','package-lock.json','tsconfig.json','eslint.config.js','.fallowrc.json','.prettierrc.json','.prettierignore','.editorconfig']:
    shutil.copy2(repo/name,root/name)
if not (root/'node_modules').exists(): (root/'node_modules').symlink_to(repo/'node_modules')
dependency=Path('/tmp/05-12-preparation')
manifest=json.loads((dependency/'file-manifest.json').read_text())
for item in manifest['files']:
    name=item['path']
    assert hashlib.sha256((dependency/name).read_bytes()).hexdigest()==item['preparedSha256'],name
    shutil.copy2(dependency/name,root/name)
plan=(repo/'.planning/phases/05-production-export-ownership/05-15-PLAN.md').read_text()
files=re.findall(r'^  - "([^"]+)"$',plan.split('autonomous:')[0],re.M)
for name in files:
    if (root/name).exists():
        target=root/'baseline'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/name,target)
(root/'owned-paths.json').write_text(json.dumps(files,indent=2)+'\n')
(root/'dependency-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(root/'05-15-PLAN.md').write_text(plan)
print({'files':len(files),'dependency_files':len(manifest['files'])})
