import { runPhases } from "../../transaction/phase-ledger.ts";
import { withLockedStateTransaction } from "../../transaction/with-state-guard.ts";

import { createInstallPlugin, type InstallTransaction } from "./install-flow.ts";

import type { InstallHooksRouting } from "./install-disable-cascade.ts";
import type { CompletionCache } from "../../shared/completion-cache.ts";

const INSTALL_TRANSACTION: InstallTransaction = {
  runPhases: (...args) => runPhases(...args),
  withLockedStateTransaction: (...args) => withLockedStateTransaction(...args),
};

/** Composes install with real transaction operations and the caller's routing and cache owners. */
export function createInstallOperation(
  hooksRouting: InstallHooksRouting,
  completionCache: CompletionCache,
): ReturnType<typeof createInstallPlugin> {
  return createInstallPlugin(INSTALL_TRANSACTION, hooksRouting, completionCache);
}
