import { parsePluginSource, samePlannedSource, sourceLogical } from "../../domain/source.ts";
import { addMarketplace as defaultAddMarketplace } from "../../orchestrators/marketplace/add.ts";
import {
  createNodeInstallPlugin,
  type InstallPluginOptions,
} from "../../orchestrators/plugin/install-flow.ts";
import { loadConfig } from "../../persistence/config-io.ts";
import {
  writeBatchedConfigEntries,
  type BatchedConfigPatch,
} from "../../persistence/config-write-back.ts";
import { locationsFor } from "../../persistence/locations.ts";
import { loadState as defaultLoadState, type ExtensionState } from "../../persistence/state-io.ts";
import { compareByNameThenScope } from "../../shared/compare-name-scope.ts";
import { ConcurrentInstallError, errorMessage, PluginShapeError } from "../../shared/errors.ts";
import { type ContentReason } from "../../shared/notification-types.ts";
import {
  type MarketplaceStatus,
  type PluginFailedMessage,
  type PluginInstalledMessage,
  type PluginSkippedMessage,
  type PluginUnavailableMessage,
} from "../../shared/notification-types.ts";
import {
  notifyWithContext,
  type MarketplaceRows,
  type Plural,
} from "../../shared/notify-context.ts";
import { withLockedStateTransaction } from "../../transaction/with-state-guard.ts";

import { IMPORT_CONTEXT, type ImportMsg } from "./execute.messaging.ts";
import { buildClaudeImportPlan } from "./marketplaces.ts";
import { loadMergedClaudeSettingsForScope as defaultLoadSettings } from "./settings.ts";

import type {
  ImportDiagnostic,
  ImportDiagnosticCode,
  MergedClaudeSettingsResult,
  PlannedPluginImport,
} from "./types.ts";
import type {
  AddMarketplaceOptions,
  AddMarketplaceOutcome,
} from "../../orchestrators/marketplace/add.ts";
import type { InstallHooksRouting } from "../../orchestrators/plugin/install-disable-cascade.ts";
import type { InstallPluginOutcome } from "../../orchestrators/types.ts";
import type { ExtensionAPI, ExtensionContext } from "../../platform/pi-api.ts";
import type { CompletionCache } from "../../shared/completion-cache.ts";
import type { Dependency } from "../../shared/concerns/soft-dep.ts";
import type { Scope } from "../../shared/types.ts";

export interface MarketplaceAddedOutcome {
  readonly kind: "marketplace-added";
  readonly scope: Scope;
  readonly marketplace: string;
  readonly reason: "added";
}

export interface MarketplaceSkipOutcome {
  readonly kind: "marketplace-skip";
  readonly scope: Scope;
  readonly marketplace: string;
  readonly reason: "already-present";
}

export interface PluginInstalledOutcome {
  readonly kind: "plugin-installed";
  readonly scope: Scope;
  readonly plugin: string;
  readonly marketplace: string;
  readonly ref: string;
  readonly reason: "installed";
  readonly resourcesChanged: boolean;
  /**
   * CMC-13 / MSG-SD-1..3: per-row soft-dep predicate inputs propagated
   * from `InstallPluginOutcome.installed`. REQUIRED (mirrors D-01) so the
   * cascade-row build site cannot read `undefined` and silently render the
   * marker as `false` (NFR-7).
   */
  readonly declaresAgents: boolean;
  readonly declaresMcp: boolean;
}

export interface PluginSkipOutcome {
  readonly kind: "plugin-skip";
  readonly scope: Scope;
  readonly plugin: string;
  readonly marketplace: string;
  readonly ref: string;
  readonly reason: "already-installed";
}

export interface ImportWarningOutcome {
  readonly kind: "plugin-warning";
  readonly scope: Scope;
  readonly plugin: string;
  readonly marketplace: string;
  readonly ref: string;
  readonly reason:
    "unmappable-marketplace-source" | "marketplace-failed" | "unavailable" | "uninstallable";
  readonly cause?: string;
}

export interface MarketplaceFailureOutcome {
  readonly kind: "marketplace-failure";
  readonly scope: Scope;
  readonly marketplace: string;
  readonly reason: "add-failed";
  readonly cause: string;
}

export interface SourceMismatchOutcome {
  readonly kind: "source-mismatch";
  readonly scope: Scope;
  readonly plugin: string;
  readonly marketplace: string;
  readonly ref: string;
  readonly reason: "source-mismatch";
  readonly cause: string;
}

export interface UnexpectedPluginFailureOutcome {
  readonly kind: "plugin-failure";
  readonly scope: Scope;
  readonly plugin: string;
  readonly marketplace: string;
  readonly ref: string;
  readonly reason: "unexpected-failure";
  readonly cause: string;
}

// Public readonly result shape. Internal mutation uses MutableImportResult.
export interface ClaudeImportExecutionResult {
  readonly addedMarketplaces: readonly MarketplaceAddedOutcome[];
  readonly installedPlugins: readonly PluginInstalledOutcome[];
  readonly skippedExistingMarketplaces: readonly MarketplaceSkipOutcome[];
  readonly skippedExistingPlugins: readonly PluginSkipOutcome[];
  readonly warnings: readonly ImportWarningOutcome[];
  readonly marketplaceFailures: readonly MarketplaceFailureOutcome[];
  readonly sourceMismatches: readonly SourceMismatchOutcome[];
  readonly unexpectedPluginFailures: readonly UnexpectedPluginFailureOutcome[];
  readonly diagnostics: readonly ImportDiagnostic[];
  readonly changedResources: boolean;
}

// Module-private builder with mutable arrays for accumulation.
interface MutableImportResult {
  addedMarketplaces: MarketplaceAddedOutcome[];
  installedPlugins: PluginInstalledOutcome[];
  skippedExistingMarketplaces: MarketplaceSkipOutcome[];
  skippedExistingPlugins: PluginSkipOutcome[];
  warnings: ImportWarningOutcome[];
  marketplaceFailures: MarketplaceFailureOutcome[];
  sourceMismatches: SourceMismatchOutcome[];
  unexpectedPluginFailures: UnexpectedPluginFailureOutcome[];
  diagnostics: ImportDiagnostic[];
  changedResources: boolean;
}

export interface ImportDeps {
  readonly loadSettings?: (
    scope: Scope,
    opts: { cwd: string },
  ) => Promise<MergedClaudeSettingsResult>;
  readonly loadState?: (scope: Scope, cwd: string) => Promise<ExtensionState>;
  readonly addMarketplace?: (
    opts: AddMarketplaceOptions,
  ) => Promise<AddMarketplaceOutcome | undefined>;
  readonly installPlugin?: (opts: InstallPluginOptions) => Promise<InstallPluginOutcome>;
}

export interface ImportClaudeSettingsOptions {
  readonly ctx: ExtensionContext;
  readonly pi: ExtensionAPI;
  readonly cwd: string;
  readonly selectedScopes: readonly Scope[];
  readonly hooksRouting: InstallHooksRouting;
  readonly completionCache: CompletionCache;
  readonly gitOps?: AddMarketplaceOptions["gitOps"];
  readonly deps?: ImportDeps;
}

function emptyResult(): MutableImportResult {
  return {
    addedMarketplaces: [],
    installedPlugins: [],
    skippedExistingMarketplaces: [],
    skippedExistingPlugins: [],
    warnings: [],
    marketplaceFailures: [],
    sourceMismatches: [],
    unexpectedPluginFailures: [],
    diagnostics: [],
    changedResources: false,
  };
}

function refLabel(plugin: PlannedPluginImport): string {
  return plugin.ref.raw;
}

// `samePlannedSource` lives in `domain/source.ts` so the pure
// `orchestrators/reconcile/plan.ts` can import it without dragging this
// module's effectful transitive closure.

function stateLoader(
  deps: ImportDeps | undefined,
): (scope: Scope, cwd: string) => Promise<ExtensionState> {
  if (deps?.loadState !== undefined) {
    return deps.loadState;
  }

  return async (scope, cwd) => defaultLoadState(locationsFor(scope, cwd).extensionRoot);
}

function settingsLoader(
  deps: ImportDeps | undefined,
): (scope: Scope, opts: { cwd: string }) => Promise<MergedClaudeSettingsResult> {
  return deps?.loadSettings ?? defaultLoadSettings;
}

function addMarketplaceFn(
  deps: ImportDeps | undefined,
): (opts: AddMarketplaceOptions) => Promise<AddMarketplaceOutcome | undefined> {
  return deps?.addMarketplace ?? defaultAddMarketplace;
}

function installPluginFn(
  deps: ImportDeps | undefined,
  hooksRouting: InstallHooksRouting,
  completionCache: CompletionCache,
): (opts: InstallPluginOptions) => Promise<InstallPluginOutcome> {
  return deps?.installPlugin ?? createNodeInstallPlugin(hooksRouting, completionCache);
}

function pluginsForMarketplace(
  plugins: readonly PlannedPluginImport[],
  marketplace: string,
): readonly PlannedPluginImport[] {
  return plugins.filter((plugin) => plugin.ref.marketplace === marketplace);
}

function pushPluginWarning(
  result: MutableImportResult,
  plugin: PlannedPluginImport,
  reason: ImportWarningOutcome["reason"],
  cause?: string,
): void {
  result.warnings.push({
    kind: "plugin-warning",
    scope: plugin.scope,
    plugin: plugin.ref.plugin,
    marketplace: plugin.ref.marketplace,
    ref: refLabel(plugin),
    reason,
    ...(cause !== undefined && { cause }),
  });
}

function pushDiagnostic(
  result: MutableImportResult,
  scope: Scope,
  code: ImportDiagnosticCode,
  message: string,
  extra?: { ref?: string; marketplace?: string },
): void {
  result.diagnostics.push({
    severity: "warning",
    scope,
    code,
    message,
    ...extra,
  });
}

// Advisory warnings (marketplace-failed / unmappable-marketplace-source /
// orphan diagnostics) are dropped: the marketplace status row already
// carries the structural signal. notify() owns severity, reload-hint,
// and soft-dep markers.

/**
 * The marketplace-level statuses the import path assigns, narrowed out of the
 * wide `MarketplaceStatus` set. Assigning any other token is a compile error at
 * the assignment site instead of a runtime signal at render time -- the same
 * narrowing `orchestrators/reconcile/notify.ts` applies to its own block type.
 */
type ImportBlockStatus = Extract<MarketplaceStatus, "added" | "updated" | "failed">;

/**
 * A marketplace header awaiting render. `status` is REQUIRED, which makes a
 * STATUSLESS HEADER unconstructible: every marketplace that reaches the cascade
 * carries a marketplace-level outcome, because a marketplace whose plugins were
 * allowed to run was either recorded (`added`), already present (`updated`), or
 * failed (`failed`).
 *
 * WR-04: that is the whole of what the type enforces. It does NOT prevent the
 * opposite shape -- a HEADERLESS ROW, i.e. a key in the sibling `rowsByMp` map
 * with no entry in `byMp`. The render pass iterates `byMp` and looks rows up by
 * key, so such rows would never be visited and would vanish without trace. What
 * actually rules that out is an invariant spanning four functions, not a type:
 * every `pushMarketplaceRow` call site is reachable only for a plugin in
 * `scopePlan.pluginsToInstall` that passed the `blockedMarketplaces` gate, and
 * `scopedPlan` (`import/marketplaces.ts`) derives `pluginsToInstall` and
 * `marketplacesToEnsure` from the same `refs` set under one scope, so the key
 * sets always match. A loud check here would be an arm no input can reach.
 */
interface MarketplaceBlock {
  readonly key: string;
  readonly name: string;
  readonly scope: Scope;
  status: ImportBlockStatus;
}

function setMarketplaceStatus(
  byMp: Map<string, MarketplaceBlock>,
  scope: Scope,
  marketplaceName: string,
  status: ImportBlockStatus,
): void {
  const key = `${scope}:${marketplaceName}`;
  const existing = byMp.get(key);
  if (existing === undefined) {
    byMp.set(key, { key, name: marketplaceName, scope, status });
    return;
  }

  existing.status = status;
}

function pushMarketplaceRow(
  rowsByMp: Map<string, ImportMsg[]>,
  scope: Scope,
  marketplaceName: string,
  row: ImportMsg,
): void {
  const key = `${scope}:${marketplaceName}`;
  const existing = rowsByMp.get(key);
  if (existing === undefined) {
    rowsByMp.set(key, [row]);
    return;
  }

  existing.push(row);
}

/**
 * The two warning reasons that reach a cascade row. D-05: the advisory
 * `marketplace-failed` / `unmappable-marketplace-source` reasons are dropped
 * before this point (the failing marketplace's own `(failed)` header carries
 * their structural signal), so this function never sees them. The
 * parameter is narrowed to the reasons that survive, which makes routing a new
 * reason to a row a compile error at the call site.
 */
type RenderedWarningReason = Extract<
  ImportWarningOutcome["reason"],
  "unavailable" | "uninstallable"
>;

function importWarningReason(reason: RenderedWarningReason): ContentReason {
  switch (reason) {
    case "unavailable":
    case "uninstallable":
      return "no longer installable";
  }
}

function dependenciesFromInstalled(o: PluginInstalledOutcome): readonly Dependency[] {
  const deps: Dependency[] = [];
  if (o.declaresAgents) {
    deps.push("agents");
  }

  if (o.declaresMcp) {
    deps.push("mcp");
  }

  // defense-in-depth: typed readonly + runtime freeze (codebase convention)
  return Object.freeze(deps);
}

/**
 * Converts a `ClaudeImportExecutionResult` into the
 * `MarketplaceNotificationMessage[]` payload for `notify()`.
 *
 * Outcome mapping: added -> "added"; already-present -> "updated";
 * marketplace failure or source mismatch -> "failed"; installed plugin ->
 * PluginInstalledMessage; already-installed plugin -> PluginSkippedMessage
 * with "already installed"; failed/unavailable plugin -> PluginFailedMessage
 * or PluginUnavailableMessage. Advisory-only warnings and orphan diagnostics
 * are silently dropped (the marketplace status row already carries the
 * structural signal).
 *
 * Iteration order: `compareByNameThenScope` (name primary
 * case-insensitive, scope secondary project-before-user). Per-plugin
 * `scope?` is omitted -- every row's scope matches its marketplace's scope
 * by construction, so `notify()` orphan-folds the bracket.
 */
function buildImportNotificationMarketplaces(
  result: ClaudeImportExecutionResult,
): Plural<MarketplaceRows<ImportMsg>> {
  const byMp = new Map<string, MarketplaceBlock>();
  const rowsByMp = new Map<string, ImportMsg[]>();

  // Marketplace-level outcomes: set status on the (scope, marketplace) tuple.
  for (const o of result.addedMarketplaces) {
    setMarketplaceStatus(byMp, o.scope, o.marketplace, "added");
  }

  for (const o of result.skippedExistingMarketplaces) {
    setMarketplaceStatus(byMp, o.scope, o.marketplace, "updated");
  }

  for (const o of result.marketplaceFailures) {
    setMarketplaceStatus(byMp, o.scope, o.marketplace, "failed");
  }

  // Source-mismatch supersedes any prior status (the import for that
  // marketplace effectively failed); dependent plugin rows accumulate as
  // PluginFailedMessage children under the (failed) header. The mp-level
  // `failed` arm carries NO `reasons` (D-46-03a): `renderMpHeader`'s failed
  // arm renders only `(failed)` and the source-mismatch reason rides the
  // child `PluginFailedMessage` row below.
  for (const o of result.sourceMismatches) {
    setMarketplaceStatus(byMp, o.scope, o.marketplace, "failed");
  }

  // Plugin rows -- orphan-fold contract: per-row `scope?` is OMITTED
  // because the row's scope matches its marketplace's scope by
  // construction (the import cascade groups outcomes by their owning scope).
  for (const o of result.installedPlugins) {
    const row: PluginInstalledMessage = {
      status: "installed",
      name: o.plugin,
      dependencies: dependenciesFromInstalled(o),
      // D-03/D-06: realized install transition -> info, reloads Pi resources.
      severity: "info",
      needsReload: true,
    };
    pushMarketplaceRow(rowsByMp, o.scope, o.marketplace, row);
  }

  for (const o of result.skippedExistingPlugins) {
    const row: PluginSkippedMessage = {
      status: "skipped",
      name: o.plugin,
      reasons: ["already installed"] as const,
      // D-03/D-06: `already installed` is a benign idempotent skip -> info,
      // no reload.
      severity: "info",
      needsReload: false,
    };
    pushMarketplaceRow(rowsByMp, o.scope, o.marketplace, row);
  }

  for (const o of result.sourceMismatches) {
    const row: PluginFailedMessage = {
      status: "failed",
      name: o.plugin,
      reasons: ["source mismatch"] as const,
      // D-03/D-06: a source-mismatch import row -> error, no reload.
      severity: "error",
      needsReload: false,
    };
    pushMarketplaceRow(rowsByMp, o.scope, o.marketplace, row);
  }

  for (const o of result.unexpectedPluginFailures) {
    const row: PluginFailedMessage = {
      status: "failed",
      name: o.plugin,
      reasons: ["not in manifest"] as const,
      // WR-03: `UnexpectedPluginFailureOutcome.cause` carries the original
      // failure as a string (`errorMessage(err)`); wrap it in an Error so the
      // depth-5 cause-chain trailer emits a diagnostic line instead of
      // discarding the message. `cause` is always populated on this outcome.
      cause: new Error(o.cause),
      // D-03/D-06: an unexpected import failure -> error, no reload.
      severity: "error",
      needsReload: false,
    };
    pushMarketplaceRow(rowsByMp, o.scope, o.marketplace, row);
  }

  for (const o of result.warnings) {
    // marketplace-failed / unmappable-marketplace-source warnings
    // have no notification representation (the failing marketplace's own
    // status: "failed" carries the structural signal; advisory-only warnings
    // are silenced).
    if (o.reason === "marketplace-failed" || o.reason === "unmappable-marketplace-source") {
      continue;
    }

    const row: PluginUnavailableMessage = {
      status: "unavailable",
      name: o.plugin,
      reasons: [importWarningReason(o.reason)],
      // WR-02: import unavailable/dependency rows are actionable -- the user
      // cannot complete the install without addressing them -> warning. Without
      // the stamp `cascadeSeverity` defaults them to `info`, so the envelope
      // never bumps to `warning` and the summary line never shows. No reload.
      severity: "warning",
      needsReload: false,
    };
    pushMarketplaceRow(rowsByMp, o.scope, o.marketplace, row);
  }

  // result.diagnostics (orphan + per-marketplace) have no notification
  // representation. The in-memory record stays on the returned result;
  // Pi runtime debug logs preserve diagnostic visibility.

  // orchestrator owns iteration order; notify does NOT sort.
  // Project-before-user tie-break per MSG-GR-3 via compareByNameThenScope.
  // defense-in-depth: typed readonly + runtime freeze (codebase convention)
  return Object.freeze(
    [...byMp.values()]
      .sort((a, b) => compareByNameThenScope(a, b))
      // WR-04: the `?? []` is the no-rows case (a marketplace added with no
      // plugins), NOT a silent absorber for orphan rows -- see the
      // `MarketplaceBlock` doc comment for the invariant that makes a
      // headerless row unreachable.
      .map((block) => blockToMarketplaceMessage(block, rowsByMp.get(block.key) ?? [])),
  );
}

/**
 * Construct the concrete per-status `MarketplaceNotificationMessage` arm
 * (TYPE-04 / D-46-03) for an accumulated `MarketplaceBlock` and its rows.
 *
 * D-05: the switch runs over the closed `ImportBlockStatus` union alone, so
 * TypeScript proves it exhaustive and a fourth member fails to compile here.
 * The import path assigns only these three tokens, and a statusless header
 * is unconstructible because `status` is required, so no `default: throw` or
 * `case undefined:` arm is needed.
 */
function blockToMarketplaceMessage(
  block: MarketplaceBlock,
  rows: readonly ImportMsg[],
): MarketplaceRows<ImportMsg> {
  const name = block.name;
  const scope = block.scope;
  // defense-in-depth: typed readonly + runtime freeze (codebase convention)
  const plugins = Object.freeze(rows);
  switch (block.status) {
    case "added":
      return { name, scope, status: "added", plugins };
    case "updated":
      return { name, scope, status: "updated", plugins };
    case "failed":
      // D-03: a failed import marketplace block -> error.
      return { name, scope, status: "failed", severity: "error", plugins };
  }
}

type ScopedImportPlan = ReturnType<typeof buildClaudeImportPlan>["scopes"][number];

/**
 * D-05: every patch this module builds carries BOTH halves, so the optional
 * fields of `BatchedConfigPatch` made each read site take a `?? {}` fallback
 * nothing could ever reach. Requiring both halves here removes those dead
 * fallbacks while staying assignable to the persistence contract.
 */
type ImportConfigPatch = Required<BatchedConfigPatch>;

/**
 * WR-07: shared failure bookkeeping for a marketplace add
 * that did not record (typed failed outcome OR unexpected throw): block
 * dependent plugin installs and attribute the cause on both the marketplace
 * row and each dependent plugin's warning row.
 */
function recordMarketplaceAddFailure(
  result: MutableImportResult,
  blockedMarketplaces: Set<string>,
  scopePlan: ScopedImportPlan,
  marketplace: ScopedImportPlan["marketplacesToEnsure"][number],
  cause: string,
): void {
  blockedMarketplaces.add(marketplace.marketplace);
  result.marketplaceFailures.push({
    kind: "marketplace-failure",
    scope: marketplace.scope,
    marketplace: marketplace.marketplace,
    reason: "add-failed",
    cause,
  });
  for (const plugin of pluginsForMarketplace(scopePlan.pluginsToInstall, marketplace.marketplace)) {
    pushPluginWarning(result, plugin, "marketplace-failed", cause);
  }
}

type PlannedMarketplace = ScopedImportPlan["marketplacesToEnsure"][number];
type PlannedPlugin = ScopedImportPlan["pluginsToInstall"][number];

/**
 * Classify an ALREADY-PRESENT marketplace against the Claude-settings source.
 * Returns true when the marketplace is settled (skip or block) and the
 * ensure-loop should move on without calling `addMarketplace`.
 */
function reconcileExistingMarketplace(
  result: MutableImportResult,
  blockedMarketplaces: Set<string>,
  scopePlan: ScopedImportPlan,
  marketplace: PlannedMarketplace,
  existingSource: unknown,
): void {
  switch (samePlannedSource(existingSource, marketplace.source)) {
    case "unknown-stored":
      // The stored source record is in an unrecognized format (e.g. a
      // hand-edited state.json). Block dependent plugins and emit a clear
      // diagnostic rather than a misleading source-mismatch message.
      //
      // WR-06: the marketplace also takes a `(failed)` header. Diagnostics
      // have no notification representation, so on their own this arm rendered
      // `(no marketplaces)` with no severity argument -- info, the token for
      // "the desired state was reached" -- while a marketplace and every plugin
      // it declares were skipped over an actionable data problem. Routing
      // through the shared add-failure bookkeeping reuses the existing
      // `marketplaceFailures -> setMarketplaceStatus("failed")` path with no new
      // vocabulary, and silences the dependent plugins' advisory rows the same
      // way a genuine add failure does.
      recordMarketplaceAddFailure(
        result,
        blockedMarketplaces,
        scopePlan,
        marketplace,
        "unrecognized stored source format",
      );
      pushDiagnostic(
        result,
        marketplace.scope,
        "unrecognized-stored-source",
        `Marketplace "${marketplace.marketplace}" has an unrecognized stored source format. Verify state.json or remove and re-add the marketplace.`,
        { marketplace: marketplace.marketplace },
      );
      break;
    case "same":
      result.skippedExistingMarketplaces.push({
        kind: "marketplace-skip",
        scope: marketplace.scope,
        marketplace: marketplace.marketplace,
        reason: "already-present",
      });
      break;
    case "different": {
      blockedMarketplaces.add(marketplace.marketplace);
      const cause = `Existing marketplace source ${sourceLogical(parsePluginSource(existingSource))} does not match Claude settings source ${marketplace.source}.`;
      for (const plugin of pluginsForMarketplace(
        scopePlan.pluginsToInstall,
        marketplace.marketplace,
      )) {
        result.sourceMismatches.push({
          kind: "source-mismatch",
          scope: plugin.scope,
          plugin: plugin.ref.plugin,
          marketplace: plugin.ref.marketplace,
          ref: refLabel(plugin),
          reason: "source-mismatch",
          cause,
        });
      }

      break;
    }
  }
}

/**
 * The import-result bucket ONE planned plugin landed in.
 *
 * CR-01: this exists so `installOnePlannedPlugin` can declare a value-returning
 * signature. TypeScript checks a `switch` for exhaustiveness only when the
 * declared return type forces a value on every path; a `void` function's switch
 * with a missing arm compiles clean. Naming the bucket makes the outcome switch
 * below TS2366-checked.
 */
type PlannedPluginBucket = "install-failed" | "installed" | "unexpected-failure";

/**
 * Record the outcome of installing ONE planned plugin and answer with the
 * result bucket it was recorded in.
 *
 * WR-02: an unexpected `installPlugin` throw routes to
 * `result.unexpectedPluginFailures` in `dispatchFailedOutcome`'s shape, so the
 * per-scope loop continues and the terminal `notify()` still fires.
 *
 * CR-01: the returned bucket is what the caller discards, not what it acts on --
 * every consumer reads the populated `result` buckets instead. The declared
 * return type is the mechanism: see `PlannedPluginBucket`.
 */
async function installOnePlannedPlugin(
  opts: ImportClaudeSettingsOptions,
  result: MutableImportResult,
  plugin: PlannedPlugin,
): Promise<PlannedPluginBucket> {
  const installPlugin = installPluginFn(opts.deps, opts.hooksRouting, opts.completionCache);
  let outcome: InstallPluginOutcome;
  try {
    outcome = await installPlugin({
      ctx: opts.ctx,
      pi: opts.pi,
      scope: plugin.scope,
      cwd: opts.cwd,
      marketplace: plugin.ref.marketplace,
      plugin: plugin.ref.plugin,
      notifications: { mode: "orchestrated" },
    });
  } catch (err) {
    result.unexpectedPluginFailures.push({
      kind: "plugin-failure",
      scope: plugin.scope,
      plugin: plugin.ref.plugin,
      marketplace: plugin.ref.marketplace,
      ref: refLabel(plugin),
      reason: "unexpected-failure",
      cause: errorMessage(err),
    });
    return "unexpected-failure";
  }

  // CR-01: a third `InstallPluginOutcome` arm must become a compile error here,
  // not get counted as a successful install in the cascade totals. The
  // mechanism is the DECLARED RETURN TYPE, not the switch: TypeScript proves a
  // switch exhaustive only when the return type forces a value on every path,
  // so this same switch inside a `void` function would let a third arm fall
  // through, record the plugin in no bucket, render no cascade row, and
  // under-count the `Import: N successes` tally with every gate green. D-05:
  // the union has exactly the two arms below, so a
  // `default: assertNever(outcome)` arm would be unreachable dead code; TS2366
  // on a missing arm enforces exhaustiveness instead.
  switch (outcome.status) {
    case "failed":
      // The collapsed `failed` status carries the typed Error directly. Narrow
      // on `instanceof PluginShapeError` plus `.kind` to recover the specific
      // failure class; everything else falls through to the unexpected bucket.
      dispatchFailedOutcome(result, plugin, outcome.error, outcome.cause);
      return "install-failed";
    case "installed":
      result.installedPlugins.push({
        kind: "plugin-installed",
        scope: plugin.scope,
        plugin: plugin.ref.plugin,
        marketplace: plugin.ref.marketplace,
        ref: refLabel(plugin),
        reason: "installed",
        resourcesChanged: outcome.resourcesChanged,
        declaresAgents: outcome.declaresAgents,
        declaresMcp: outcome.declaresMcp,
      });
      result.changedResources ||= outcome.resourcesChanged;
      for (const w of outcome.postCommitWarnings ?? []) {
        pushDiagnostic(result, plugin.scope, "post-install-warning", w, { ref: refLabel(plugin) });
      }

      return "installed";
  }
}

/**
 * WR-07: add ONE planned marketplace in ORCHESTRATED mode and dispatch on the
 * typed outcome.
 *
 * Standalone mode is wrong here: a classified precondition failure (duplicate
 * name, stale clone, invalid manifest, unsupported source, source missing)
 * does NOT throw there -- it fires its own standalone notify, which breaks
 * import's one-cascade-per-command discipline, and returns undefined. The
 * import then recorded the marketplace as (added), never blocked its
 * dependent plugins, and every install failed with a misleading reason.
 */
async function addOnePlannedMarketplace(
  opts: ImportClaudeSettingsOptions,
  result: MutableImportResult,
  blockedMarketplaces: Set<string>,
  scopePlan: ScopedImportPlan,
  marketplace: PlannedMarketplace,
): Promise<void> {
  const addMarketplace = addMarketplaceFn(opts.deps);
  try {
    const outcome = await addMarketplace({
      ctx: opts.ctx,
      pi: opts.pi,
      scope: marketplace.scope,
      cwd: opts.cwd,
      rawSource: marketplace.source,
      completionCache: opts.completionCache,
      notifications: { mode: "orchestrated" },
      ...(opts.gitOps !== undefined && { gitOps: opts.gitOps }),
    });
    if (outcome?.status === "added") {
      result.addedMarketplaces.push({
        kind: "marketplace-added",
        scope: marketplace.scope,
        marketplace: marketplace.marketplace,
        reason: "added",
      });
      return;
    }

    recordMarketplaceAddFailure(
      result,
      blockedMarketplaces,
      scopePlan,
      marketplace,
      outcome?.cause ?? "addMarketplace returned no outcome in orchestrated mode",
    );
  } catch (err) {
    // Defensive: orchestrated mode coerces classified failures into typed
    // outcomes, so only a genuinely unexpected throw lands here.
    recordMarketplaceAddFailure(
      result,
      blockedMarketplaces,
      scopePlan,
      marketplace,
      errorMessage(err),
    );
  }
}

// The import workflow is intentionally linear: ensure marketplaces, record
// diagnostics, then install plugins while preserving per-item continuation
// semantics.
async function executeScopedPlan(
  opts: ImportClaudeSettingsOptions,
  result: MutableImportResult,
  scopePlan: ScopedImportPlan,
): Promise<void> {
  const loadState = stateLoader(opts.deps);

  let state: ExtensionState;
  try {
    state = await loadState(scopePlan.scope, opts.cwd);
  } catch (err) {
    pushDiagnostic(
      result,
      scopePlan.scope,
      "settings-read-error",
      `Cannot read ${scopePlan.scope} scope state: ${errorMessage(err)}`,
    );
    return;
  }

  const blockedMarketplaces = new Set<string>();

  for (const marketplace of scopePlan.marketplacesToEnsure) {
    const existing = state.marketplaces[marketplace.marketplace];
    if (existing !== undefined) {
      reconcileExistingMarketplace(
        result,
        blockedMarketplaces,
        scopePlan,
        marketplace,
        existing.source,
      );
      continue;
    }

    await addOnePlannedMarketplace(opts, result, blockedMarketplaces, scopePlan, marketplace);
  }

  for (const skipped of scopePlan.skippedPlugins) {
    pushPluginWarning(
      result,
      { scope: skipped.scope, ref: skipped.ref },
      "unmappable-marketplace-source",
      skipped.reason,
    );
  }

  for (const plugin of scopePlan.pluginsToInstall) {
    if (blockedMarketplaces.has(plugin.ref.marketplace)) {
      continue;
    }

    const existingPlugin = state.marketplaces[plugin.ref.marketplace]?.plugins[plugin.ref.plugin];
    if (existingPlugin !== undefined) {
      result.skippedExistingPlugins.push({
        kind: "plugin-skip",
        scope: plugin.scope,
        plugin: plugin.ref.plugin,
        marketplace: plugin.ref.marketplace,
        ref: refLabel(plugin),
        reason: "already-installed",
      });
      continue;
    }

    await installOnePlannedPlugin(opts, result, plugin);
  }

  // WB-03: after all per-entry orchestrated-mode addMarketplace
  // + installPlugin calls complete for THIS scope, run a per-scope batched
  // post-pass under ONE withLockedStateTransaction. Per-entry orchestrators
  // SKIPPED their own write-back (WR-09 orchestrated-mode discipline) so the
  // post-pass owns the ONLY write to claude-plugins.json for the import
  // command.
  //
  // WR-01: the post-pass also REPAIRS missing config
  // declarations for already-present (skipped) entries. If a previous
  // import's post-pass failed (the defensive catch below records a
  // diagnostic and moves on), state carries entries the config never
  // declared -- and without the repair, a re-run would skip them as
  // "already-present" while the next reconcile plans the undeclared
  // marketplace for REMOVAL and its plugins for UNINSTALL. The repair makes
  // a re-run converge CONSTRUCTIVELY (re-declare what import installed)
  // instead of destructively.
  await writeBatchedConfigForScope(opts, result, scopePlan);
}

/**
 * WB-03: per-scope batched post-pass.
 *
 * Reads back `result` for entries WHOSE scope matches this scope, builds a
 * `BatchedConfigPatch` (one entry per successful addedMarketplaces + one per
 * successful installedPlugins), and writes the patch under ONE
 * withLockedStateTransaction with exactly ONE saveConfig call.
 *
 * WR-01: skip outcomes (`skippedExistingMarketplaces` /
 * `skippedExistingPlugins`) are included as REPAIR candidates -- written
 * ONLY when the loaded config does not already declare the key (the
 * key-absence gate preserves RECON-05 byte stability for the all-declared
 * steady state). This makes a previously failed post-pass converge
 * constructively on the next import run instead of leaving
 * recorded-but-undeclared entries the reconcile planner would tear down.
 *
 * Target: import does NOT support `--local` (per RESEARCH project structure;
 * the flag is per-command and not on the import surface), so the post-pass
 * targets `locations.configJsonPath` unconditionally.
 *
 * Source: verbatim `rawSource` from `scopePlan.marketplacesToEnsure` keyed by
 * marketplace name, preserving the `samePlannedSource` contract.
 *
 * CFG-03: invalid claude-plugins.json aborts THIS scope's post-pass but does
 * NOT throw -- other scopes' post-passes still run. State was already saved
 * by per-entry orchestrators; this post-pass writes only the config.
 *
 * Empty batch (no successful additions AND no missing-declaration repairs):
 * SKIP entirely (RECON-05 byte-stable).
 */
async function writeBatchedConfigForScope(
  opts: ImportClaudeSettingsOptions,
  result: MutableImportResult,
  scopePlan: ScopedImportPlan,
): Promise<void> {
  const scope = scopePlan.scope;
  const { ensure, repair } = buildBatchedPatchForScope(result, scopePlan);
  if (isEmptyPatch(ensure) && isEmptyPatch(repair)) {
    return;
  }

  const locations = locationsFor(scope, opts.cwd);
  const targetConfigPath = locations.configJsonPath;

  try {
    await withLockedStateTransaction(locations, async () => {
      const cfg = await loadConfig(targetConfigPath);
      if (cfg.status === "invalid") {
        // CFG-03: per-scope abort. Surface as a diagnostic; do not save.
        pushDiagnostic(
          result,
          scope,
          "settings-read-error",
          `Cannot write ${scope} scope claude-plugins.json: existing file is invalid.`,
        );
        return;
      }

      const current = cfg.status === "valid" ? cfg.config : { schemaVersion: 1 as const };
      // WR-01: repairs apply ONLY when the key is absent from the loaded
      // config (already-declared entries are untouched -- byte stability).
      const batch = mergeEnsureAndRepairs(ensure, repair, current);
      if (isEmptyPatch(batch)) {
        // Everything already declared -- no write, mtime stable (RECON-05).
        return;
      }

      await writeBatchedConfigEntries(current, targetConfigPath, locations.scopeRoot, batch);
      // NO tx.save() -- state was already committed by per-entry
      // orchestrators inside their own withStateGuard / withLockedStateTransaction
      // closures. The bounded race between the last per-entry lock release and
      // this batched-save lock acquire converges via the WR-01 repair pass:
      // a re-run of import re-declares any entry the failed write left
      // undeclared (constructive convergence, not a reconcile teardown).
    });
  } catch (err) {
    // Defensive: a write-back failure (disk full, EACCES, lock contention)
    // does not abort the import command result -- per-entry orchestrators
    // already committed state. Surface as a per-scope diagnostic.
    pushDiagnostic(
      result,
      scope,
      "settings-read-error",
      `Failed to write ${scope} scope claude-plugins.json batched post-pass: ${errorMessage(err)}`,
    );
  }
}

function buildBatchedPatchForScope(
  result: MutableImportResult,
  scopePlan: ScopedImportPlan,
): { ensure: ImportConfigPatch; repair: ImportConfigPatch } {
  // Map marketplace name -> verbatim rawSource so the batched patch records
  // `source: rawSource` exactly as the user/Claude settings declared it
  // (`samePlannedSource` contract).
  const rawSourceByName = new Map<string, string>();
  for (const mp of scopePlan.marketplacesToEnsure) {
    rawSourceByName.set(mp.marketplace, mp.source);
  }

  const marketplaces: Record<string, { source: string }> = {};
  for (const added of result.addedMarketplaces) {
    if (added.scope !== scopePlan.scope) {
      continue;
    }

    const rawSource = rawSourceByName.get(added.marketplace);
    if (rawSource === undefined) {
      // Defensive: should not happen -- every addedMarketplaces entry
      // originated from a marketplacesToEnsure entry. Skip rather than
      // synthesize a wrong source.
      continue;
    }

    marketplaces[added.marketplace] = { source: rawSource };
  }

  const plugins: Record<string, Record<string, never>> = {};
  for (const installed of result.installedPlugins) {
    if (installed.scope !== scopePlan.scope) {
      continue;
    }

    const key = `${installed.plugin}@${installed.marketplace}`;
    plugins[key] = {};
  }

  return {
    ensure: { marketplaces, plugins },
    repair: buildRepairPatchForScope(result, scopePlan, rawSourceByName),
  };
}

/**
 * WR-01: already-present (skipped) entries are REPAIR
 * candidates -- state carries them, so a missing config declaration is a
 * divergence the reconcile planner would resolve DESTRUCTIVELY (teardown).
 * The caller applies these only when the loaded config lacks the key.
 */
function buildRepairPatchForScope(
  result: MutableImportResult,
  scopePlan: ScopedImportPlan,
  rawSourceByName: ReadonlyMap<string, string>,
): ImportConfigPatch {
  const marketplaces: Record<string, { source: string }> = {};
  for (const skipped of result.skippedExistingMarketplaces) {
    if (skipped.scope !== scopePlan.scope) {
      continue;
    }

    const rawSource = rawSourceByName.get(skipped.marketplace);
    if (rawSource === undefined) {
      continue;
    }

    marketplaces[skipped.marketplace] = { source: rawSource };
  }

  const plugins: Record<string, Record<string, never>> = {};
  for (const skipped of result.skippedExistingPlugins) {
    if (skipped.scope !== scopePlan.scope) {
      continue;
    }

    plugins[`${skipped.plugin}@${skipped.marketplace}`] = {};
  }

  return { marketplaces, plugins };
}

/**
 * WR-01: merge the always-written `ensure` patch with the subset of `repair`
 * entries whose keys are ABSENT from the loaded config. Already-declared
 * keys are dropped so the all-declared steady state stays byte-stable
 * (RECON-05) -- the post-pass then skips the save entirely when nothing
 * remains.
 */
function mergeEnsureAndRepairs(
  ensure: ImportConfigPatch,
  repair: ImportConfigPatch,
  current: { marketplaces?: Record<string, unknown>; plugins?: Record<string, unknown> },
): ImportConfigPatch {
  const marketplaces = { ...ensure.marketplaces };
  for (const [name, patch] of Object.entries(repair.marketplaces)) {
    if (current.marketplaces?.[name] === undefined && marketplaces[name] === undefined) {
      marketplaces[name] = patch;
    }
  }

  const plugins = { ...ensure.plugins };
  for (const [key, patch] of Object.entries(repair.plugins)) {
    if (current.plugins?.[key] === undefined && plugins[key] === undefined) {
      plugins[key] = patch;
    }
  }

  return { marketplaces, plugins };
}

function isEmptyPatch(batch: ImportConfigPatch): boolean {
  return Object.keys(batch.marketplaces).length === 0 && Object.keys(batch.plugins).length === 0;
}

/**
 * Recover the semantic dispatch from the typed `Error` in the collapsed
 * `status: "failed"` outcome. `PluginShapeError.kind === "already-installed"`
 * and `ConcurrentInstallError` both route to the skip bucket;
 * `not-in-manifest` and `(no-)not-installable` route to the
 * unavailable / uninstallable warnings; everything else lands in
 * `unexpectedPluginFailures`.
 */
function dispatchFailedOutcome(
  result: MutableImportResult,
  plugin: PlannedPluginImport,
  error: Error,
  cause: string,
): void {
  if (error instanceof ConcurrentInstallError) {
    result.skippedExistingPlugins.push({
      kind: "plugin-skip",
      scope: plugin.scope,
      plugin: plugin.ref.plugin,
      marketplace: plugin.ref.marketplace,
      ref: refLabel(plugin),
      reason: "already-installed",
    });
    return;
  }

  if (error instanceof PluginShapeError) {
    // Switch on `error.shape.kind` for compile-time exhaustiveness.
    switch (error.shape.kind) {
      case "already-installed":
        result.skippedExistingPlugins.push({
          kind: "plugin-skip",
          scope: plugin.scope,
          plugin: plugin.ref.plugin,
          marketplace: plugin.ref.marketplace,
          ref: refLabel(plugin),
          reason: "already-installed",
        });
        return;
      case "not-in-manifest":
        pushPluginWarning(result, plugin, "unavailable", cause);
        return;
      case "not-installable":
      case "no-longer-installable":
        pushPluginWarning(result, plugin, "uninstallable", cause);
        return;
    }
  }

  result.unexpectedPluginFailures.push({
    kind: "plugin-failure",
    scope: plugin.scope,
    plugin: plugin.ref.plugin,
    marketplace: plugin.ref.marketplace,
    ref: refLabel(plugin),
    reason: "unexpected-failure",
    cause,
  });
}

export async function importClaudeSettings(
  opts: ImportClaudeSettingsOptions,
): Promise<ClaudeImportExecutionResult> {
  const result = emptyResult();
  const loadSettings = settingsLoader(opts.deps);
  const settingsResults = await Promise.all(
    opts.selectedScopes.map(async (scope) => ({
      scope,
      loaded: await loadSettings(scope, { cwd: opts.cwd }),
    })),
  );

  for (const loaded of settingsResults) {
    result.diagnostics.push(...loaded.loaded.diagnostics);
  }

  const plan = buildClaudeImportPlan(
    settingsResults.map((entry) => ({ scope: entry.scope, settings: entry.loaded.settings })),
  );
  result.diagnostics.push(...plan.diagnostics);

  for (const scopePlan of plan.scopes) {
    await executeScopedPlan(opts, result, scopePlan);
  }

  // D-20-02 / D-19-02: cascade construction
  // mirrors the reinstall outcome recipe at
  // orchestrators/plugin/reinstall-record.ts; execute.ts substitutes the
  // import-cascade variant set (added / updated / failed marketplaces).
  // Truly catastrophic throws bubble to Pi runtime -- better for debugging
  // than a polished error message that masks the bug. The inner
  // executeScopedPlan try/catch covers expected loadState failures.
  // D-12 / OUT-07: the import cascade is bulk (one import touches many
  // marketplaces) -> Plural row cardinality. D-02: thread IMPORT_CONTEXT + the
  // rows through notifyWithContext, so import's per-row rendering dispatches
  // through its own render map (MOD-03), never the central renderPluginRow
  // switch.
  const marketplaces: Plural<MarketplaceRows<ImportMsg>> =
    buildImportNotificationMarketplaces(result);
  // OUT-04 / D-04: import is a plural (bulk) operation -> emit the trailing
  // per-operation tally under the `Import` label.
  notifyWithContext(opts.ctx, opts.pi, IMPORT_CONTEXT, marketplaces, undefined, "plural");

  return result;
}
